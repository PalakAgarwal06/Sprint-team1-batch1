package com.example.demo.controller;

import java.sql.Date;
import com.example.demo.dto.ApiResponse;
import com.example.demo.dto.ProductLineDTO;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Order;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductLine;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.services.CustomerServiceImpl;
import com.example.demo.services.OrderService;
import com.example.demo.services.OrderServiceImpl;

@RestController

@RequestMapping("/api/v1/orders")

public class OrdersController {

	private final OrderServiceImpl orderService;

	@Autowired
	public OrdersController(OrderServiceImpl orderService) {
		this.orderService = orderService;
	}

	@Autowired
	CustomerServiceImpl customerService;

	@GetMapping("/{orderNumber}")
	public ResponseEntity<?> getOrderById(@PathVariable("orderNumber") int orderNumber) throws OrderNotFoundException {
		return new ResponseEntity<Order>(orderService.getOrderById(orderNumber), HttpStatus.OK);
	}

	@PutMapping("/{orderNumber}/{shippedDate}")
	public ResponseEntity<Order> updateOrderShippedDate(@PathVariable("orderNumber") int orderNumber,
			@PathVariable("shippedDate") Date shippedDate) throws OrderNotFoundException {

		return new ResponseEntity<Order>(orderService.updateOrderShippedDate(orderNumber, shippedDate), HttpStatus.OK);
	}

	@GetMapping("/order_date/{orderDate}")
	public ResponseEntity<List<Order>> getOrdersByOrderDate(@PathVariable("orderDate") Date orderDate) {
		return new ResponseEntity<List<Order>>(orderService.getOrdersByOrderDate(orderDate), HttpStatus.OK);
	}

	@GetMapping("/required_date/{requireDate}")
	public ResponseEntity<List<Order>> getOrdersByRequiredDate(@PathVariable("requireDate") Date requiredDate) {
		return new ResponseEntity<List<Order>>(orderService.getOrdersByRequiredDate(requiredDate), HttpStatus.OK);
	}

	@GetMapping("/shipped_date/{shippedDate}")
	public ResponseEntity<List<Order>> getOrdersByShippedDate(@PathVariable("shippedDate") Date shippedDate) {
		return new ResponseEntity<List<Order>>(orderService.getOrdersByShippedDate(shippedDate), HttpStatus.OK);
	}

	@GetMapping("/status/{status}")
	public ResponseEntity<List<Order>> getOrdersByStatus(@PathVariable("status") String status) {
		return new ResponseEntity<List<Order>>(orderService.getOrdersByStatus(status), HttpStatus.OK);
	}

	@PutMapping("{orderNumber}/status/{status}")
	public ResponseEntity<Order> updateOrderStatus(@PathVariable("orderNumber") int orderNumber,
			@PathVariable("status") String status) throws OrderNotFoundException {

		return new ResponseEntity<Order>(orderService.updateOrderStatus(orderNumber, status), HttpStatus.OK);
	}
	// updated

	@GetMapping("/customer/{customerNumber}/status/{status}")
	public ResponseEntity<List<Order>> getOrdersByCustomerNumberAndStatus(
			@PathVariable("customerNumber") int customerNumber, @PathVariable("status") String status) {
		return new ResponseEntity<List<Order>>(orderService.getOrdersByCustomerNumberAndStatus(customerNumber, status),
				HttpStatus.OK);
	}

	@GetMapping("/{order_id}/product_names")
	public ResponseEntity<List<String>> getProductNamesByOrderId(@PathVariable("order_id") int orderId) {
		List<String> productNames = orderService.getProductNamesByOrderId(orderId);
		return new ResponseEntity<>(productNames, HttpStatus.OK);
	}

	@GetMapping("/products")
	public List<Product> getAllProducts() {
		return orderService.findAllProducts();
	}

	@GetMapping("/{order_status}/orders")
	public List<Order> getDeliveredOrdersWithSameDate(@PathVariable("order_status") String status) {
		return orderService.findDeliveredOrdersWithSameDate(status);
	}

	@GetMapping("/product_and_product_line_details")
	public List<ProductLineDTO> getProductAndProductLineDetailsByShipmentDate() {
		Date shipmentDate = java.sql.Date.valueOf("2004-07-22"); // Convert the date to java.sql.Date
		return orderService.findProductAndProductLineDetailsByShipmentDate(shipmentDate);
	}

	@GetMapping("/{orderNumber}/products")
	public ResponseEntity<List<Product>> getProductByOrderNumber(@PathVariable int orderNumber)
			throws OrderNotFoundException {
		List<Product> plist = orderService.getProductByOrderNumber(orderNumber);
		if (plist.isEmpty()) {
			throw new OrderNotFoundException("");
		} else {
			return new ResponseEntity<List<Product>>(plist, HttpStatus.FOUND);
		}
	}

	@PostMapping("/customer_number/{customerNumber}")
	public ResponseEntity<Order> addOrder(@PathVariable("customerNumber") int customerNumber, @RequestBody Order order)
			throws CustomerNotFoundException {
		Customers cust = customerService.getCustomerById(customerNumber);
		order.setCustomer(cust);

		Order addedOrder = orderService.createOrder(order);
		return new ResponseEntity<Order>(addedOrder, HttpStatus.CREATED);
	}

}