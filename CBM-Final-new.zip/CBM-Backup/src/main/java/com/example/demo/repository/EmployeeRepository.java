package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entities.Employees;



public interface EmployeeRepository extends JpaRepository<Employees, Integer> {
	
	 @Query("SELECT e FROM Employees e JOIN e.offices o WHERE o.city = :city")
	  
	  List<Employees> findByOfficeCity(@Param("city") String city);
	 
	 @Query("SELECT e FROM Employees e JOIN e.offices o WHERE o.code = :code")
	  
	  List<Employees> findByOfficeCode(@Param("code") int code);
	 
		
	 @Modifying
	 @Transactional
	 @Query("UPDATE Employees e SET e.offices = (SELECT o FROM Offices o WHERE o.code = :code) WHERE e.employeeNumber = :employeeNumber")
	 void assignOfficeToEmployee(@Param("code") int code, @Param("employeeNumber") int employeeNumber);
	 
	 @Query("SELECT reportsTo FROM Employees e WHERE e.employeeNumber = :employeeNumber")
	 Employees findReportsTo(@Param("employeeNumber")int employeeNumber);
	 
	 @Query("SELECT e FROM Employees e WHERE e.reportsTo = :employee")
	 List<Employees> findReportingTo(@Param("employee")Employees employee);
		 
			 

}
	 
	 


