package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;

public interface OfficesRepository extends JpaRepository<Offices, Integer> {
	
	@Query("SELECT o FROM Offices o WHERE o.city IN :cityNames")
    List<Offices> findOfficesByCityNames(@Param("cityNames") List<String> cityNames);
	
	@Query("SELECT e.customers FROM Employees e JOIN e.offices o WHERE o.code = :officeCode")
    List<Customers> findCustomersByOfficeCode(@Param("officeCode") int officeCode);
}
