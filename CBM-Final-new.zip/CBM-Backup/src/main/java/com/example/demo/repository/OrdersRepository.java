package com.example.demo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.dto.ProductLineDTO;
import com.example.demo.entities.Order;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductLine;

public interface OrdersRepository extends JpaRepository<Order, Integer> {
	
	@Query("SELECT od.product FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")
	List<Product> findProductDetailByOrderNumber(@Param("orderNumber") int orderNumber);
	
	@Query("SELECT o FROM Order o WHERE o.requiredDate = :requiredDate")
    List<Order> findOrdersByRequiredDate(@Param("requiredDate") Date requiredDate);
	
	@Query("SELECT o FROM Order o WHERE o.shippedDate = :shippedDate")
    List<Order> findOrdersByShippedDate(@Param("shippedDate") Date shippedDate);
	
	@Query("SELECT o FROM Order o WHERE o.orderDate = :orderDate")
    List<Order> findOrdersByOrderDate(@Param("orderDate") Date orderDate);
	
	@Query("SELECT o FROM Order o WHERE o.status = :status")
    List<Order> findOrdersByStatus(@Param("status") String status);
	
	 @Query("SELECT o FROM Order o WHERE o.customer.customerNumber = :customerNumber AND o.status = :status")
	    List<Order> findOrdersByCustomerNumberAndStatus(
	        @Param("customerNumber") int customerNumber,
	        @Param("status") String status
	    );
	 
	 @Query("SELECT od.product.productName FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")
	    List<String> findProductNamesByOrderId(@Param("orderNumber") int orderNumber);
	 
	 @Query("SELECT od.product FROM OrderDetails od")
	    List<Product> findAllProducts();
	 
	 @Query("SELECT o FROM Order o WHERE o.status = :status AND DATE(o.shippedDate) = DATE(o.requiredDate)")
	    List<Order> findDeliveredOrdersWithSameDate(@Param("status") String status);
	 
	 @Query("SELECT NEW com.example.demo.dto.ProductLineDTO(p.productName, pl.productLine) " +
		       "FROM Order o " +
		       "JOIN o.orderDetails od " +
		       "JOIN od.product p " +
		       "JOIN p.productLine pl " +
		       "WHERE DATE(o.shippedDate) = :shipmentDate")
		List<ProductLineDTO> findProductAndProductLineDetailsByShipmentDate(@Param("shipmentDate") Date shipmentDate);

}
