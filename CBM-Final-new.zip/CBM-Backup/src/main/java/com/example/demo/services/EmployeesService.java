package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.Employees;
import com.example.demo.exception.EmployeeNotFoundException;

public interface EmployeesService {

	Employees getEmployeeById(int employeeNumber) throws EmployeeNotFoundException;

	List<Employees> getAllEmployees();

	Employees createEmployee(Employees employee);

	Employees updateEmployee(Employees employee) throws EmployeeNotFoundException;

	void deleteEmployee(int employeeNumber) throws EmployeeNotFoundException;
	
	Employees updateRole(int employeeId, String jobTitle)throws EmployeeNotFoundException ;
	
	List<Employees> getByOfficeCity(String city) ;
	
	List<Employees> getByOfficeCode(int code) ;
	
	Employees updateReporting(int empId, int empNewNo)throws EmployeeNotFoundException ;
	
	
	  void assignOfficeToEmployee(int officeCode, int employeeNumber) throws
	  EmployeeNotFoundException;
	  
	  Employees reportsTo(int employeeNumber);
	  List<Employees> reportingTo(Employees employeeNumber);
	 
	
}
