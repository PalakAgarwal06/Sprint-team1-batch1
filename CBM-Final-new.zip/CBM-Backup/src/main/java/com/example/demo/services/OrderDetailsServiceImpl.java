package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.OrderDetailDTO;
import com.example.demo.entities.OrderDetails;
import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.repository.OrderDetailsRepository;
import com.example.demo.repository.ProductsRepository;

@Service
public class OrderDetailsServiceImpl implements OrderDetailsService {

	@Autowired
	private OrderDetailsRepository orderDetailRepo;

	@Autowired
	private ProductService productService;

	@Autowired
	private OrderService orderService;

	@Override
	public OrderDetails addOrderDetails(OrderDetails orderDetails) {
		// TODO Auto-generated method stub
		return orderDetailRepo.save(orderDetails);
	}

	@Override
	public List<OrderDetails> getByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.findByOrderNumber(orderNumber);
	}

	@Override
	public double getOrderDetailsByMaxPriceOrder() {
		// TODO Auto-generated method stub
		return orderDetailRepo.getMaxPriceForOrder();
	}

	@Override
	public int getOrderDetailCountByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.getOrderDetailCountByOrderNumber(orderNumber);
	}

	/*
	 * @Override public int getOrderDetailCountByOrderNumber(int orderNumber) { //
	 * TODO Auto-generated method stub return
	 * orderDetailRepo.getOrderDetailCountByOrderNumber(orderNumber); }
	 */

	@Override
	public Double getTotalOrderAmount(int orderNumber) {
		return orderDetailRepo.getTotalOrderAmount(orderNumber);
	}

	@Override
	public Double getTotalSale() {
		return orderDetailRepo.getTotalSale();
	}

	@Override
	public String updateQuantityOrdered(int orderNumber, String productCode, int quantityOrdered) {
		int updatedRows = orderDetailRepo.updateQuantityOrdered(orderNumber, productCode, quantityOrdered);

		if (updatedRows > 0) {
			return "Product Quantity updated successfully";
		}

		return "Order Details not found";
	}

	@Override
	public void addOrderDetails(OrderDetailDTO orderDetailsDTO) throws Exception {
		OrderDetails orderDetails = new OrderDetails();
		orderDetails.setProduct(productService.getProductById(orderDetailsDTO.getProductCode()));
		orderDetails.setOrders(orderService.getOrderById(orderDetailsDTO.getOrderNumber()));
		orderDetails.setQuantityOrdered(orderDetailsDTO.getQuantityOrdered());
		orderDetails.setPriceEach(orderDetailsDTO.getPriceEach());
		orderDetails.setOrderLineNumber(orderDetailsDTO.getOrderLineNumber());

		orderDetailRepo.save(orderDetails);
	}

}