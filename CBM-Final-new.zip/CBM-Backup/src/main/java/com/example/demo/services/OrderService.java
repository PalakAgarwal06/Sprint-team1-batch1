
package com.example.demo.services;

import java.util.Date;
import java.util.List;

import com.example.demo.dto.ProductLineDTO;
import com.example.demo.entities.Order;
import com.example.demo.entities.Product;
import com.example.demo.exception.OrderNotFoundException;

public interface OrderService {

	Order createOrder(Order order);

	List<Order> getAllOrder(Order order);

	Order updateOrder(Order order) throws OrderNotFoundException;

	Order getOrderById(int orderNumber) throws OrderNotFoundException;

	void deleteOrder(int orderNumber) throws OrderNotFoundException;

	Order updateOrderShippedDate(int orderNumber, Date shippedDate) throws OrderNotFoundException;

	List<Order> getOrdersByOrderDate(Date requiredDate);

	List<Order> getOrdersByRequiredDate(Date requiredDate);

	List<Order> getOrdersByShippedDate(Date shippedDate);

	List<Order> getOrdersByStatus(String status);

	Order updateOrderStatus(int orderNumber, String status) throws OrderNotFoundException;

	List<Order> getOrdersByCustomerNumberAndStatus(int customerNumber, String status);

	List<Product> getProductByOrderNumber(int orderNumber);

	List<String> getProductNamesByOrderId(int orderId);

	List<Product> findAllProducts();

	List<Order> findDeliveredOrdersWithSameDate(String status);

	List<ProductLineDTO> findProductAndProductLineDetailsByShipmentDate(java.sql.Date shipmentDate);

}
