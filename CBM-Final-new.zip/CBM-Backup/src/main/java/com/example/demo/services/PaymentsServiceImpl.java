package com.example.demo.services;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Payments;
import com.example.demo.repository.PaymentsRepository;
import com.example.demo.repository.*;

@Service
public class PaymentsServiceImpl implements PaymentsService {
	@Autowired
	PaymentsRepository paymentsRepository;

	@Autowired
	CustomersRepository customersRepository;

	public List<Payments> searchPaymentsByCheckNumber(String checkNumber) {
		return paymentsRepository.findByCheckNumber(checkNumber);
	}

	public List<Payments> getPaymentsByPaymentDate(Date paymentDate) {
		return paymentsRepository.findPaymentsByPaymentDate(paymentDate);
	}

	public Double getTotalAmountByCustomerNumber(int customerNumber) {
		return paymentsRepository.findTotalAmountByCustomerNumber(customerNumber);
	}

	public List<Customers> getCustomersByCheckNo(String checkno) {
		return paymentsRepository.findCustomersByCheckNo(checkno);
	}

	public Customers getCustomerWithMaxPaymentAmount() {
		return paymentsRepository.findCustomerWithMaxPaymentAmount();

	}

	public List<Customers> getCustomersByPaymentDateRange(Date startPaydate, Date endPaydate) {
		return paymentsRepository.findCustomersByPaymentDateRange(startPaydate, endPaydate);
	}

	public List<Customers> getCustomersByPaymentDate(Date paymentDate) {
		return paymentsRepository.findCustomersByPaymentDate(paymentDate);
	}

	public String updateCheckNumberForPayment(int customerNumber, String checkNumber, String newCheckNumber) {
		int updatedRows = paymentsRepository.updateCheckNumberForPayment(customerNumber, checkNumber, newCheckNumber);
		if (updatedRows > 0) {
			return "Check number updated Successfully";
		} else {
			return "No payment found for the specified customer and check number.";
		}
	}

	public String updatePaymentAmountForCheck(int customerNumber, String checkNumber, Double newAmount) {
		int updatedRows = paymentsRepository.updatePaymentAmountForCheck(customerNumber, checkNumber, newAmount);
		if (updatedRows > 0) {
			return "Payment amount details updated Successfully";
		} else {
			return "No payment found for the specified customer and check number.";
		}
	}

	public List<PaymentCustomerDTO> getPaymentDetailsForCustomer(int customer_id) {
		Customers customer = customersRepository.findById(customer_id).orElse(null);
		if (customer == null) {
			// Handle customer not found
			return Collections.emptyList();
		}

		List<Payments> payments = paymentsRepository.findByCustomer(customer);

		List<PaymentCustomerDTO> paymentCustomerDTOs = payments.stream()
				.map(payment -> new PaymentCustomerDTO(payment, customer)).collect(Collectors.toList());

		return paymentCustomerDTOs;
	}

	@Override
	public List<Offices> getOfficeWithMaxPaymentCollection() {
		return paymentsRepository.findOfficeWithMaxPaymentCollection();
	}

}
