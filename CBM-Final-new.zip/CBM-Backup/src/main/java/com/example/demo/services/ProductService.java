package com.example.demo.services;

import java.util.*;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.dto.ProductDTO;
import com.example.demo.entities.Product;

public interface ProductService {

	Product createProduct(Product product);

	List<Product> getAllProduct(Product Product);

	Product updateProduct(Product Product) throws ProductNotFoundException;

	Product getProductById(String productCode) throws ProductNotFoundException;

	void deleteProduct(String productCode) throws ProductNotFoundException;

//	void updateQuantityInStock(String productCode, int newQuantity)throws ProductNotFoundException;
//
//	void updateProductName(String productCode, String newName);
//	

	void updateQuantityInStock(String prodcutCode, int quantity) throws ProductNotFoundException;

	void updateProductName(String productCode, String newName) throws ProductNotFoundException;

	void updateProductMSRP(String productCode, double newMSRP) throws ProductNotFoundException;

	void updateProductVendor(String productCode, String newVendor) throws ProductNotFoundException;

	void updateProductScale(String productCode, String newScale) throws ProductNotFoundException;

	void updateProductBuyPrice(String productCode, double newBuyPrice) throws ProductNotFoundException;

	Product getProductByName(String productName) throws ProductNotFoundException;

	List<Product> searchByProductScale(String productScale) throws ProductNotFoundException;

	List<Product> searchByProductVendor(String productVendor) throws ProductNotFoundException;

	List<ProductDTO> getHighlyDemandedProducts();

}
