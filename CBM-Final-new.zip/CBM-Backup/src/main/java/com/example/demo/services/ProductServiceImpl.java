package com.example.demo.services;

import java.util.List;
import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.dto.ProductDTO;
import com.example.demo.entities.Product;

import com.example.demo.repository.ProductsRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductsRepository prepo;

	@Override

	public Product createProduct(Product product) {

		return prepo.save(product);

	}

	@Override

	public List<Product> getAllProduct(Product Product) {

		return prepo.findAll();

	}

	@Override

	public Product updateProduct(Product Product) throws ProductNotFoundException {

		// TODO Auto-generated method stub

		if (prepo.findById(Product.getProductCode()).isEmpty()) {

			throw new ProductNotFoundException("Product not found");

		}

		else {

			return prepo.save(Product);

		}

	}

	@Override

	public Product getProductById(String productCode) throws ProductNotFoundException {

		if (prepo.findById(productCode).isEmpty()) {

			throw new ProductNotFoundException("Product not found");

		}

		else {

			return prepo.findById(productCode).get();

		}

	}

	@Override

	public void deleteProduct(String productCode) throws ProductNotFoundException {

		// TODO Auto-generated method stub

		if (prepo.findById(productCode).isEmpty()) {

			throw new ProductNotFoundException("Product not found");

		}

		else {

			prepo.deleteById(productCode);

		}

	}

	@Override
	public void updateQuantityInStock(String productCode, int newQuantity) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setQuantityInStock(newQuantity);
			prepo.save(product);
		}
	}

	@Override
	public void updateProductVendor(String productCode, String newVendor) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setProductVendor(newVendor);
			prepo.save(product);
		}
	}

	@Override
	public void updateProductScale(String productCode, String newScale) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setProductScale(newScale);
			prepo.save(product);
		}
	}

	@Override
	public void updateProductMSRP(String productCode, double newMSRP) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setMsrp(newMSRP);
			prepo.save(product);
		}
	}

	@Override
	public void updateProductBuyPrice(String productCode, double newBuyPrice) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setBuyPrice(newBuyPrice);
			prepo.save(product);
		}
	}

	@Override
	public void updateProductName(String productCode, String newName) throws ProductNotFoundException {
		Product product = prepo.findByProductCode(productCode);
		if (product != null) {
			product.setProductName(newName);
			prepo.save(product);
		}

	}

	public Product getProductByName(String productName) {
		return prepo.findByProductName(productName);
	}

	public List<Product> searchByProductScale(String productScale) {
		List<Product> productList = prepo.findAll();
		return productList.stream().filter(product -> product.getProductScale().equalsIgnoreCase(productScale))
				.collect(Collectors.toList());
	}

	public List<Product> searchByProductVendor(String productVendor) {
		List<Product> productList = prepo.findAll();
		return productList.stream().filter(product -> product.getProductVendor().equalsIgnoreCase(productVendor))
				.collect(Collectors.toList());
	}

	@Override
	public List<ProductDTO> getHighlyDemandedProducts() {
		List<Product> highlyDemandedProducts = prepo.findHighDemandProducts(10);
		return convertToDTOs(highlyDemandedProducts);
	}

	private List<ProductDTO> convertToDTOs(List<Product> products) {
		List<ProductDTO> productDTOs = new ArrayList<>();
		for (Product product : products) {
			ProductDTO productDTO = new ProductDTO();
			productDTO.setProductCode(product.getProductCode());
			productDTO.setProductName(product.getProductName());
			productDTO.setProductLine(product.getProductLine().getProductLine());
			productDTO.setProductScale(product.getProductScale());
			productDTO.setProductVendor(product.getProductVendor());
			productDTO.setDescription(product.getDescription());
			productDTO.setQuantityInStock(product.getQuantityInStock());
			productDTO.setBuyPrice(product.getBuyPrice());
			productDTO.setMsrp(product.getMsrp());
			productDTOs.add(productDTO);
		}
		return productDTOs;
	}

}
