package com.example.demo.uicontroller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.entities.ProductLine;

import com.example.demo.exception.ProductLineNotFoundException;

import com.example.demo.services.ProductLineService;

import java.util.*;

@Controller

@RequestMapping("/api/ui/productLine")

public class ProductLineUIController {

	@Autowired

	private ProductLineService productLineService;

	@GetMapping("/all")

	public String getAllProductLine(Model model) {

		List<ProductLine> productLines = productLineService.getAllProductLine();

		model.addAttribute("productLines", productLines);

		return "allProductLine";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/delete/{productLine}")

	public String getProductLineAddForm(@PathVariable("productLine") String productLine)
			throws ProductLineNotFoundException {

		System.out.println(productLine);

		productLineService.deleteProductLine(productLine);

		return "redirect:/api/ui/productLine/all";

	}

	@GetMapping("/add")

	public String getProductLineAddForm(Model model) {

		ProductLine productLines = new ProductLine();

		productLines.setProductLine("12343");

		model.addAttribute("newProductLine", productLines);

		return "addProductLine";

	}

	@PostMapping("/add")

	public String addNewProductLine(@ModelAttribute("newProductLine") ProductLine produductLine) {

		productLineService.createProductLine(produductLine);

		return "redirect:/api/ui/productLine/all";

	}

	@GetMapping("/view/{productLine}")

	public String getProductLineById(Model model, @PathVariable("productLine") String productLine)
			throws ProductLineNotFoundException {

		ProductLine productLines = productLineService.getProductLineById(productLine);

		model.addAttribute("productLines", productLines);

		return "oneProductLine";

	}

	@RequestMapping(value = "/update/{productLine}", method = RequestMethod.GET)
	public String getUpdateProductLineForm(@PathVariable("productLine") String productLine, Model model)
			throws Exception {
		ProductLine productLines = productLineService.getProductLineById(productLine);
		model.addAttribute("updatedProductLine", productLines);
		return "updateProductLine";
	}

	@PostMapping("/update/{productLine}")
	public String updateProductLine(@PathVariable("productLine") String productLine,
			@ModelAttribute("productLines") ProductLine updatedProductLine, Model model) {
		try {
			ProductLine productLines = productLineService.getProductLineById(productLine);

			productLines.setTextDescription(updatedProductLine.getTextDescription());
			productLines.setHtmlDescription(updatedProductLine.getHtmlDescription());

			productLineService.updateProductLine(productLines);

			return "redirect:/api/ui/productLine/all";
		} catch (ProductLineNotFoundException e) {
			// Handle the exception, e.g., show an error message
			return "error"; // Create an error template
		}
	}

}
