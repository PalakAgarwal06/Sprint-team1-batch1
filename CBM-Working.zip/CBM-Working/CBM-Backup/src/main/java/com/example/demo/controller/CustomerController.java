package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;

import com.example.demo.dto.OrderPaymentDetailsDto;
import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.services.CustomerServiceImpl;
import com.example.demo.services.EmployeesServiceImpl;
import com.example.demo.services.PaymentsServiceImpl;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {
	@Autowired
    CustomerServiceImpl customerService;
	
	@Autowired
	PaymentsServiceImpl paymentService;
	
	
	
	@GetMapping("/customer_name/{customer_name}")
	public ResponseEntity<List<Customers>> getCustomersByCustomerName(@PathVariable("customer_name") String customerName) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchCustomersByName(customerName),HttpStatus.OK);

	}
	
	@GetMapping("/city/{city}")
	public ResponseEntity<List<Customers>> getCustomersByCity(@PathVariable("city") String city) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchCustomersByCity(city),HttpStatus.OK);

	}
	
	@GetMapping("/customer_number/{customer_number}")
	public ResponseEntity<Customers> getCustomersByCustomerNumber(@PathVariable("customer_number") int customerNumber) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.getCustomerById(customerNumber),HttpStatus.OK);

	}
	
	@GetMapping("/country/{country}")
	public ResponseEntity<List<Customers>> getCustomersByCountry(@PathVariable("country") String country) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchByCountry(country),HttpStatus.OK);

	}

	@GetMapping("/phone/{phone}")
	public ResponseEntity<Customers> getCustomersByPhone(@PathVariable("phone") String phone) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.searchByPhoneNumber(phone),HttpStatus.OK);

	}
	
	@GetMapping("/postalCode/{postalCode}")
	public ResponseEntity<List<Customers>> getCustomersByPostalCode(@PathVariable("postalCode") String postalCode) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchCustomersByPostalCode(postalCode),HttpStatus.OK);

	}
	
	@GetMapping("/contactFirstName/{contactFirstName}")
	public ResponseEntity<Customers> getCustomersByFirstName(@PathVariable("contactFirstName") String contactFirstName) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.searchByContactFirstName(contactFirstName),HttpStatus.OK);

	}
	
	
	@GetMapping("/contactLastName/{contactLastName}")
	public ResponseEntity<Customers> getCustomersByLastName(@PathVariable("contactLastName") String contactLastName) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.searchByContactLastName(contactLastName),HttpStatus.OK);

	}
	
	@GetMapping("/creditLimit/{creditLimit}")
	public ResponseEntity<List<Customers>> getCustomersBycreditLimit(@PathVariable("creditLimit") double creditLimit) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchCustomersByCreditLimit(creditLimit),HttpStatus.OK);

	}
	
	@GetMapping("/creditLimit/{maxcreditLimit}")
	public ResponseEntity<List<Customers>> getCustomersByMaxCreditLimit(@PathVariable("maxcreditLimit") double maxcreditLimit) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchByHighCreditLimit(maxcreditLimit),HttpStatus.OK);

	}
	
	@GetMapping("/creditLimit/{mincreditLimit}")
	public ResponseEntity<List<Customers>> getCustomersByMinCreditLimit(@PathVariable("maxcreditLimit") double maxcreditLimit) throws CustomerNotFoundException{

		return new ResponseEntity<List<Customers>>(customerService.searchByHighCreditLimit(maxcreditLimit),HttpStatus.OK);

	}
	
	@GetMapping("/credit_range/{minCredit}/{maxCredit}")
	public ResponseEntity<List<Customers>> findByCreditRange(@PathVariable("minCredit") double minCreditLimit,
			                                                 @PathVariable("maxCredit") double maxCreditLimit) {
		return new ResponseEntity<List<Customers>>(customerService.getCustomersInCreditRange(minCreditLimit, maxCreditLimit), HttpStatus.OK);

	}
	
	
	
	@PutMapping("/{customer_number}/{customer_name}")

	public ResponseEntity<Customers> updateCustomerName(@PathVariable("customer_number") int customerNumber, @PathVariable("customer_name") String customerName) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.updateCustomerName(customerNumber,customerName),HttpStatus.OK);

	}
	
	@PutMapping("/{customer_number}/{customer_first_name}")

	public ResponseEntity<Customers> updateCustomerFirstName(@PathVariable("customer_number") int customerNumber, @PathVariable("customer_first_name") String customerFirstName) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.updateCustomerFirstName(customerNumber, customerFirstName),HttpStatus.OK);

	}
	
	@PutMapping("/{customer_number}/{customer_last_name}")

	public ResponseEntity<Customers> updateCustomerLastName(@PathVariable("customer_number") int customerNumber, @PathVariable("customer_last_name") String customerLastName) throws CustomerNotFoundException{

		return new ResponseEntity<Customers>(customerService.updateCustomerLastName(customerNumber, customerLastName),HttpStatus.OK);

	}
	
	@PostMapping("/")
	public ResponseEntity<Customers> addCustomer(@RequestBody Customers customer) throws CustomerNotFoundException{
		Customers customerAdded = customerService.createCustomer(customer);
        return new ResponseEntity<Customers>(customerAdded, HttpStatus.CREATED);
	}
	
	
	 @GetMapping("/{customer_id}/paymentdetails")
	    public ResponseEntity<List<PaymentCustomerDTO>> getPaymentDetailsForCustomer(@PathVariable int customer_id) {
	        List<PaymentCustomerDTO> paymentCustomerDTOs = paymentService.getPaymentDetailsForCustomer(customer_id);
	        return ResponseEntity.ok(paymentCustomerDTOs);
	    }
	 
	 @GetMapping("/{customerName}/order_payment_details")
	    public ResponseEntity<List<OrderPaymentDetailsDto>> getOrderPaymentDetailsForCustomer(
	            @PathVariable("customerName") String customerName) {
	        List<OrderPaymentDetailsDto> result = customerService.getOrderPaymentDetailsForCustomer(customerName);
	        return ResponseEntity.ok(result);
	    }
	
	

}
