package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Employees;
import com.example.demo.entities.Offices;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.services.EmployeesService;
import com.example.demo.services.EmployeesServiceImpl;
import com.example.demo.services.OfficeService;

@RestController

@RequestMapping("/api/v1/employee")

public class EmployeeController {

	@Autowired
	OfficeService officeService;

	private final EmployeesServiceImpl employeeService;

	@Autowired
	public EmployeeController(EmployeesServiceImpl employeeService) {
		this.employeeService = employeeService;
	}

	@GetMapping("/")

	public ResponseEntity<List<Employees>> getAllEmployees() {

		return new ResponseEntity<List<Employees>>(employeeService.getAllEmployees(), HttpStatus.OK);

	}

	@GetMapping("/{employeeNumber}")
	public ResponseEntity<Employees> getEmployeeById(@PathVariable("employeeNumber") int employeeNumber)
			throws EmployeeNotFoundException {
		return new ResponseEntity<Employees>(employeeService.getEmployeeById(employeeNumber), HttpStatus.OK);

	}

	@GetMapping("/all_details/{city}")
	public ResponseEntity<List<Employees>> findByOfficeCity(@PathVariable("city") String city) {
		return new ResponseEntity<List<Employees>>(employeeService.getByOfficeCity(city), HttpStatus.OK);

	}

	@PostMapping("/add")
	public ResponseEntity<Employees> addEmployee(@RequestBody Employees employee) {
		employeeService.createEmployee(employee);
		return new ResponseEntity<>(HttpStatus.CREATED);
	}

	@PutMapping("/{employeeId}/update-role")
	public ResponseEntity<Employees> updateEmployeeRole(@PathVariable("employeeId") int employeeId,
			@RequestParam String newRole) throws EmployeeNotFoundException {
		return new ResponseEntity<Employees>(employeeService.updateRole(employeeId, newRole), HttpStatus.OK);
	}

	@GetMapping("/all_employee_details/{office_code}")
	public ResponseEntity<List<Employees>> findByOfficeCode(@PathVariable("office_code") int code) {
		return new ResponseEntity<List<Employees>>(employeeService.getByOfficeCode(code), HttpStatus.OK);

	}

	@PutMapping("/{employeeNumber}/reports_to/{newEmployeeNo}")

	public ResponseEntity<Employees> updateReporting(@PathVariable("employeeNumber") int employeeId,
			@PathVariable("newEmployeeNo") int newEmployeeNo) throws EmployeeNotFoundException {
		return new ResponseEntity<Employees>(employeeService.updateReporting(employeeId, newEmployeeNo), HttpStatus.OK);

	}

	@PutMapping("{employeeNumber}/mapToOffice/{office_code}/")
	public ResponseEntity<Employees> assignOffice(@PathVariable("office_code") int officeCode,
			@PathVariable("employeeNumber") int employeeNumber) throws EmployeeNotFoundException {
		return new ResponseEntity<Employees>(employeeService.assignOfficeToEmployee(officeCode, employeeNumber),
				HttpStatus.OK);
	}

	@PostMapping("/office_code/{office_code}")
	public ResponseEntity<String> addEmployee(@PathVariable("office_code") int office_code,
			@RequestBody Employees employee) throws OfficeNotFoundException {
		Offices office = officeService.getOfficebyId(office_code);
		employee.setOffices(office);

		Employees employeeAdded = employeeService.createEmployee(employee);
		return new ResponseEntity<String>("employeeAdded", HttpStatus.CREATED);
	}

}
