package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Employees;
import com.example.demo.entities.Order;
import com.example.demo.entities.OrderDetails;
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.services.OrderService;
import com.example.demo.services.OrderdetailsService;

@RestController
@RequestMapping("/api/v1/orderdetails")
public class OrderDetailsController {

	@Autowired
	OrderService orderService;
	
	@Autowired
	private OrderdetailsService service;
	
	@PostMapping("/add")
	public ResponseEntity<String> addOrderDetails(@PathVariable("orderNumber")int orderNumber,@RequestBody OrderDetails orderDetail) throws OrderNotFoundException {
		/*
		 * Order order = orderService.getOrderById(orderNumber);
		 * orderDetail.setOrders(order);
		 */
		OrderDetails oDetails =service.addOrderDetails(orderDetail);
		
		//Employees employeeAdded = employeeService.createEmployee(employee);
		//return new ResponseEntity<String>("employeeAdded", HttpStatus.CREATED);
		return new ResponseEntity<String>("Record Created Successfully", HttpStatus.OK);
	}
	
	@GetMapping("/{orderNumber}")
	public ResponseEntity<?> getByOrderNumber(@PathVariable int orderNumber) {
		List<OrderDetails> orderDetails = service.getByOrderNumber(orderNumber);
		if(!orderDetails.isEmpty()) {
			return new ResponseEntity<>(orderDetails, HttpStatus.OK);
		}
		return new ResponseEntity<>("not found ", HttpStatus.INTERNAL_SERVER_ERROR);
		
}
	
}
