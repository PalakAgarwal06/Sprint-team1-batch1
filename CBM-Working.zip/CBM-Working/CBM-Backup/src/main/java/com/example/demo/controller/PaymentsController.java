package com.example.demo.controller;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Payments;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.exception.PaymentsNotFoundException;
import com.example.demo.services.CustomerService;
import com.example.demo.services.CustomerServiceImpl;
import com.example.demo.services.PaymentsService;
import com.example.demo.services.PaymentsServiceImpl;

@RestController

@RequestMapping("/api/v1/payments")

public class PaymentsController {

	private final PaymentsServiceImpl paymentsService;

	@Autowired
	public PaymentsController(PaymentsServiceImpl paymentsService) {
		this.paymentsService = paymentsService;
	}
	
	@Autowired
	CustomerService customerService;

	@GetMapping("/{check_number}")
	public ResponseEntity<?> searchPaymentsByCheckNumber(@PathVariable("check_number") String checkNumber) {
		try {
			List<Payments> paymentsList = paymentsService.searchPaymentsByCheckNumber(checkNumber);
			if (paymentsList.isEmpty()) {
				return new ResponseEntity<>("No payments found for check number: " + checkNumber, HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity<>(paymentsList, HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/date/{paymentDate}")
	public ResponseEntity<?> getPaymentsByPaymentDate(
			@PathVariable("paymentDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date paymentDate) {
		try {
			List<Payments> paymentsList = paymentsService.getPaymentsByPaymentDate(paymentDate);
			if (paymentsList.isEmpty()) {
				return new ResponseEntity<>("No payments found for the specified payment date.", HttpStatus.NOT_FOUND);
			} else {
				return new ResponseEntity<>(paymentsList, HttpStatus.OK);
			}
		} catch (Exception e) {
			return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/total_amount/{customer_number}")
	public ResponseEntity<?> getTotalAmountByCustomerNumber(@PathVariable("customer_number") int customer_number) {
		return new ResponseEntity<Double>(paymentsService.getTotalAmountByCustomerNumber(customer_number),
				HttpStatus.OK);
	}

	@GetMapping("/customers/{checkNumber}")
	public ResponseEntity<?> getCustomerByCheckNumber(@PathVariable("checkNumber") String checkNumber) {
		return new ResponseEntity<List<Customers>>(paymentsService.getCustomersByCheckNo(checkNumber), HttpStatus.OK);
	}

	

	@GetMapping("/customers/{startPayDate}/{endPaydate}")
	public ResponseEntity<List<Customers>> getCustomerByPayDateRange(
			@PathVariable("startPayDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date startPayDate,
			@PathVariable("endPayDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date endPayDate) {
		return new ResponseEntity<List<Customers>>(
				paymentsService.getCustomersByPaymentDateRange(startPayDate, endPayDate), HttpStatus.OK);
	}

	@GetMapping("/{paymentDate}/customers")
	public ResponseEntity<List<Customers>> getCustomerByPaymentDate(
			@PathVariable("paymentDate") @DateTimeFormat(pattern = "yyyy-MM-dd") Date paymentDate) {
		return new ResponseEntity<List<Customers>>(paymentsService.getCustomersByPaymentDate(paymentDate),
				HttpStatus.OK);
	}
	
	 @PostMapping("/create/{customer_number}")
	    public ResponseEntity<Payments> createPayment(@PathVariable("customer_number")int customer_number,@RequestBody Payments payment) throws CustomerNotFoundException {
	     Customers customer = customerService.getCustomerById(customer_number);   
		 payment.setCustomer(customer);
	     Payments createdPayment = paymentsService.createPayment();
	        return new ResponseEntity<>(createdPayment, HttpStatus.CREATED);
	    }
	
	 @GetMapping("/maxamount")
	    public PaymentCustomerDTO getCustomerByMaxPaymentAmount() {
	        return paymentsService.getCustomerWithMaxPaymentAmount();
	    }

	
	 
}
