package com.example.demo.controller;

import java.math.BigDecimal;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ProductNameSaleAmountDTO;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductLine;
import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.exception.ProductLineNotFoundException;
import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.services.ProductLineService;
import com.example.demo.services.ProductService;
import com.example.demo.services.ProductServiceImpl;

 

@RestController

@RequestMapping("/api/v1/products")

 

public class ProductController {

	



	private final ProductServiceImpl productService;
	
	@Autowired
	public ProductController(ProductServiceImpl productService) {
        this.productService = productService;
    }
	
	@Autowired
	ProductLineService productLineService;
	
	
	@PostMapping("/create/product_line/{product_line}")
    public ResponseEntity<String> createProduct(@PathVariable("product_line") String product_line,@RequestBody Product product) throws ProductLineNotFoundException {
         ProductLine productLine = productLineService.getProductLineById(product_line);
         product.setProductLine(productLine);
		Product createdProduct = productService.createProduct(product);
        return new ResponseEntity<String>("product created", HttpStatus.CREATED);
    }
	
	@PutMapping("update/{product_code}/{quantity_in_stock}")
    public ResponseEntity<String> updateQuantityInStock(
        @PathVariable("product_code") String productCode,
        @PathVariable("quantity_in_stock") int newQuantity
    ) {
        try {
            productService.updateQuantityInStock(productCode, newQuantity);
            return new ResponseEntity<>("Quantity in stock updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/name/{product_name}")
    public ResponseEntity<String> updateProductName(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_name") String newName
    ) {
        try {
            productService.updateProductName(productCode, newName);
            return new ResponseEntity<>("Product name updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/scale/{product_scale}")
    public ResponseEntity<String> updateProductScale(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_scale") String newScale
    ) {
        try {
            productService.updateProductScale(productCode, newScale);
            return new ResponseEntity<>("Product Scale updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/vendor/{product_vendor}")
    public ResponseEntity<String> updateProductVendor(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_vendor") String newVendor
    ) {
        try {
            productService.updateProductVendor(productCode, newVendor);
            return new ResponseEntity<>("Product Vendor updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/msrp/{product_msrp}")
    public ResponseEntity<String> updateProductMSRP(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_msrp") double newMSRP
    ) {
        try {
            productService.updateProductMSRP(productCode, newMSRP);
            return new ResponseEntity<>("Product MSRP updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/buy_price/{product_buyPrice}")
    public ResponseEntity<String> updateProductBuyPrice(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_buyPrice") double newBuyPrice
    ) {
        try {
            productService.updateProductBuyPrice(productCode, newBuyPrice);
            return new ResponseEntity<>("Product MSRP updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/{productCode}")
    public ResponseEntity<?> getProductById(@PathVariable("productCode") String productCode) {
        try {
            Product product = productService.getProductById(productCode);
            return new ResponseEntity<>(product, HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/product_name/{product_name}")
    public ResponseEntity<?> getProductByName(@PathVariable("product_name") String productName) {
        try {
            Product product = productService.getProductByName(productName);
            if (product != null) {
                return new ResponseEntity<>(product, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/product_scale/{product_scale}")
    public ResponseEntity<?> searchByProductScale(@PathVariable("product_scale") String productScale) {
        try {
            List<Product> productList = productService.searchByProductScale(productScale);
            if (!productList.isEmpty()) {
                return new ResponseEntity<>(productList, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("No products found with the specified scale", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
	@GetMapping("/product_vendor/{product_vendor}")
    public ResponseEntity<?> searchByProductVendor(@PathVariable("product_vendor") String productVendor) {
        try {
            List<Product> productList = productService.searchByProductVendor(productVendor);
            if (!productList.isEmpty()) {
                return new ResponseEntity<>(productList, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("No products found for the specified vendor", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/total-sale-amount-for-each-product")
    public ResponseEntity<List<ProductNameSaleAmountDTO>> getTotalSaleAmountForEachProduct() {
        List<ProductNameSaleAmountDTO> productAmountList = productService.getTotalSaleAmountForEachProduct();
        if (!productAmountList.isEmpty()) {
            return new ResponseEntity<>(productAmountList, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
	
	
	@GetMapping("/{productCode}/total_sale")
    public  ResponseEntity<BigDecimal> getTotalSaleAmountForProduct(@PathVariable String productCode) {
        double totalAmount = productService.getTotalSaleAmountForProduct(productCode);
        
        	return new ResponseEntity<BigDecimal>(HttpStatus.OK);
        
    }
	
	
	@GetMapping("/{productCode}/totalOrderedQty")
	public ResponseEntity<?> getTotalOrderedQuantity(@PathVariable String productCode) throws ProductNotFoundException {
		Product product = productService.getProductById(productCode);
		if (product != null) {
			return new ResponseEntity<>(product.getQuantityInStock(), HttpStatus.OK);
		}
		return new ResponseEntity<>("Product Details not found", HttpStatus.NOT_FOUND);
	}
}








