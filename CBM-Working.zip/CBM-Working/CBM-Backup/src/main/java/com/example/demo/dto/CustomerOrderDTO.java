package com.example.demo.dto;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Order;

public class CustomerOrderDTO {
	private Customers customer;
	private Order order;
	public CustomerOrderDTO(Order order,Customers customer) {
		super();
		this.order = order;
		this.customer = customer;
		
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}

}
