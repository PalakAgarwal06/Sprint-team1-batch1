package com.example.demo.dto;

import  com.example.demo.entities.OrderDetails;
import  com.example.demo.entities.Payments;

 

public class OrderPaymentDetailsDto {
	private OrderDetails orderDetail;
	private Payments payment;
	public OrderPaymentDetailsDto(OrderDetails orderDetail, Payments payment) {
		super();
		this.orderDetail = orderDetail;
		this.payment = payment;
	}
	public OrderDetails getOrderDetail() {
		return orderDetail;
	}
	public void setOrderDetail(OrderDetails orderDetail) {
		this.orderDetail = orderDetail;
	}
	public Payments getPayment() {
		return payment;
	}
	public void setPayment(Payments payment) {
		this.payment = payment;
	}



 

}