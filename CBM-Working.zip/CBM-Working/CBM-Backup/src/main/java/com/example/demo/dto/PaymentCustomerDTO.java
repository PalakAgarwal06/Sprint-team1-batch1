package com.example.demo.dto;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Payments;
 

public class PaymentCustomerDTO {
	private Payments payment;
	private Customers customer;
	
	
	public PaymentCustomerDTO(Payments payment, Customers customer) {
		super();
		this.payment = payment;
		this.customer = customer;
	}
	public Payments getPayment() {
		return payment;
	}
	public void setPayment(Payments payment) {
		this.payment = payment;
	}
	public Customers getCustomer() {
		return customer;
	}
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
}


