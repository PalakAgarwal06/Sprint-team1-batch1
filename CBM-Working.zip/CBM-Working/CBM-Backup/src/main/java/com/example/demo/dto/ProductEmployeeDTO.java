package com.example.demo.dto;

import com.example.demo.entities.Employees;
import com.example.demo.entities.Product;

public class ProductEmployeeDTO {
	private Product product;
	private Employees employee;
	
	
	
	public ProductEmployeeDTO(Product product, Employees employee) {
		super();
		this.product = product;
		this.employee = employee;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Employees getEmployee() {
		return employee;
	}
	public void setEmployee(Employees employee) {
		this.employee = employee;
	}
}
