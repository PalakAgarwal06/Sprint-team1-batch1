package com.example.demo.dto;

public class ProductNameSaleAmountDTO {
    private String productName;
    private double totalSaleAmount;
    

    

	public ProductNameSaleAmountDTO(String productName, double totalSaleAmount) {
		super();
		this.productName = productName;
        this.totalSaleAmount = totalSaleAmount;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getTotalSaleAmount() {
        return totalSaleAmount;
    }

    public void setTotalSaleAmount(double totalSaleAmount) {
        this.totalSaleAmount = totalSaleAmount;
    }
}
