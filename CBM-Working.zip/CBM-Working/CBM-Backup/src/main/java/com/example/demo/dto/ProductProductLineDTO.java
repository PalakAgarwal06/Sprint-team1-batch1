package com.example.demo.dto;

import com.example.demo.entities.Product;
import com.example.demo.entities.ProductLine;

public class ProductProductLineDTO {
	private Product product;
	private ProductLine productLine;
	public ProductProductLineDTO(Product product, ProductLine productLine) {
		super();
		this.product = product;
		this.productLine = productLine;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public ProductLine getProductLine() {
		return productLine;
	}
	public void setProductLine(ProductLine productLine) {
		this.productLine = productLine;
	}
}
