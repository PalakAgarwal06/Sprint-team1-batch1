package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.dto.OrderPaymentDetailsDto;
import com.example.demo.entities.Customers;

public interface CustomersRepository extends JpaRepository<Customers, Integer>{

	@Query("SELECT c FROM Customers c WHERE c.customerName = :name")    
	List<Customers> findByCustomerName(@Param("name")String name);

	@Query("SELECT c FROM Customers c WHERE c.city = :city")
	List<Customers> findByCity(@Param("city")String city);
	
	@Query("SELECT c FROM Customers c WHERE c.city = :city")
    List<Customers> findCustomersByCity(@Param("city") String city);
	
	@Query("SELECT c FROM Customers c WHERE c.country = :country")
    List<Customers> findByCountry(@Param("country") String country);

    
    @Query("SELECT c FROM Customers c WHERE c.phone = :phone")
    Customers findByPhone(@Param("phone") String phone);

    
    @Query("SELECT c FROM Customers c WHERE c.customerFirstName = :firstName")
    Customers findByContactFirstName(@Param("firstName") String firstName);


    @Query("SELECT c FROM Customers c WHERE c.contactLastName = :lastName")
    Customers findByContactLastName(@Param("lastName") String lastName);
    
    @Query("SELECT c FROM Customers c WHERE c.creditLimit > : creditLimit")
    List<Customers> findByHighCreditLimit(@Param("creditLimit") double creditLimit);
    
    @Query("SELECT c FROM Customers c WHERE c.creditLimit < : creditLimit")
    List<Customers> findByLowCreditLimit(@Param("creditLimit") double creditLimit);
    
    @Query("SELECT c FROM Customers c WHERE c.creditLimit = :creditLimit")
    List<Customers> findByCreditLimit(@Param("creditLimit") double creditLimit);
    
    @Query("SELECT c FROM Customers c WHERE c.creditLimit >= :startCredit AND c.creditLimit <= :endCredit")  
	 List<Customers> findCustomersInCreditRange(@Param("startCredit") double startCredit, @Param("endCredit") double endCredit);

 

    @Query("SELECT c FROM Customers c WHERE c.postalCode = :postalCode")
    List<Customers> findByPostalCode(@Param("postalCode") String postalCode);
    
   
    
    
    
    
    

}
