package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.entities.Employees;



public interface EmployeeRepository extends JpaRepository<Employees, Integer> {
	
	 @Query("SELECT e FROM Employees e JOIN e.offices o WHERE o.city = :city")
	  
	  List<Employees> findByOfficeCity(@Param("city") String city);
	 
	 @Query("SELECT e FROM Employees e JOIN e.offices o WHERE o.code = :code")
	  
	  List<Employees> findByOfficeCode(@Param("code") int code);
	 
		
		  @Query("UPDATE Employees e SET e.offices = (SELECT o FROM Offices o WHERE o.code = :code) WHERE e.employeeNumber = :employeeNumber"
		  )
		  
		  Employees assignOfficeToEmployee(@Param("code") int
		  code, @Param("employeeNumber") int employeeNumber);
		 
			 

}
	 
	 


