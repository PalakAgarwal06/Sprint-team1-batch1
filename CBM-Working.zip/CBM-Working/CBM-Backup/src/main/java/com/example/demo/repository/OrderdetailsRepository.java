
  package com.example.demo.repository;
  
  import java.util.List;
  
  import javax.transaction.Transactional;
  
  import org.springframework.data.jpa.repository.JpaRepository; import
  org.springframework.data.jpa.repository.Modifying; import
  org.springframework.data.jpa.repository.Query; import
  org.springframework.data.repository.query.Param;

import com.example.demo.dto.OrderPaymentDetailsDto;
import com.example.demo.entities.OrderDetails;
  
  public interface OrderdetailsRepository extends JpaRepository<OrderDetails,
  Integer>{
  
		/*
		 * List<OrderDetails> findByPriceEachEqualsOrderByPriceEachDesc(Double
		 * maxPrice); Double findMaxPrice();
		 * 
		 * 
		 * @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od")
		 * Double getTotalSale();
		 * 
		 * @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od WHERE od.order.orderNumber = :orderNumber"
		 * ) Double calculateTotalAmountByOrderNumber(@Param("orderNumber") Integer
		 * orderNumber);
		 * 
		 * 
		 * @Modifying
		 * 
		 * @Transactional
		 * 
		 * @Query("UPDATE OrderDetails od " + "SET od.quantityOrdered = :newQuantity " +
		 * "WHERE od.order.orderNumber = :orderNumber " +
		 * "AND od.product.productCode = :productCode") void
		 * updateQuantityOrdered(Integer orderNumber, String productCode, Integer
		 * newQuantity); List<OrderDetails> findByOrderOrderNumber(Integer orderNumber);
		 * 
		 * @Query("SELECT od FROM OrderDetails od WHERE od.order.orderNumber = :orderNumber"
		 * ) List<OrderDetails> findByOrderNumber(@Param("orderNumber") Integer
		 * orderNumber);
		 * 
		 * @Query("SELECT COUNT(od) FROM OrderDetail od WHERE od.attribute = :attribute"
		 * ) Long countOrderDetailsByAttribute(@Param("attribute") String attribute);
		 * 
		 */
  
	  @Query("SELECT NEW com.example.demo.dto.OrderPaymentDetailsDto(od, p) " +
	            "FROM OrderDetails od " +
	            "JOIN od.orders o " +
	            "JOIN o.customer c " +
	            "JOIN c.payment p " +
	            "WHERE c.customerName = :customerName")
	     List<OrderPaymentDetailsDto> findOrderPaymentDetailsByCustomerName(@Param("customerName") String customerName);
  
	  @Query("SELECT od FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")
		List<OrderDetails> findByOrderNumber(@Param("orderNumber") int orderNumber);
	  
		/*
		 * @Query("SELECT SUM(p.amount) " + "FROM Payments p " + "JOIN p.customers c " +
		 * "JOIN c.order o " + "WHERE o.orderNumber = :orderNumber") double
		 * getTotalAmountByOrderNumber(@Param("orderNumber") int orderNumber);
		 */
	  
  }
 