package com.example.demo.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Payments;

public interface PaymentsRepository extends JpaRepository<Payments, String> {
	
	List<Payments> findByCheckNumber(String checkNumber);
	
	
	
	@Query("SELECT p FROM Payments p WHERE p.paymentDate = :paymentDate")

    List<Payments> findPaymentsByPaymentDate(@Param("paymentDate") Date paymentDate);
	
	 @Query("SELECT SUM(p.amount) FROM Payments p WHERE p.customer.customerNumber = :customerNumber")
	 Double findTotalAmountByCustomerNumber(@Param("customerNumber") int customerNumber);
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c " +
	           "WHERE p.checkNumber = :checkNumber")
	    List<Customers> findCustomersByCheckNo(@Param("checkNumber") String checkNumber);
	 
		
		
		/*
		 * @Query("SELECT c FROM Payments p JOIN p.customer c " +
		 * "GROUP BY c.customerNumber " + "ORDER BY MAX(p.amount) DESC") Customers
		 * findCustomerWithMaxPaymentAmount();
		 */
	 
	  @Query("SELECT NEW com.example.demo.dto.PaymentCustomerDTO(p, p.customer) " +
	           "FROM Payments p " +
	           "WHERE p.amount = (SELECT MAX(p2.amount) FROM Payments p2)")
	    PaymentCustomerDTO findCustomerWithMaxPaymentAmount();
		 
		 
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c " +
	           "WHERE p.paymentDate BETWEEN :startPaydate AND :endPaydate")
	    List<Customers> findCustomersByPaymentDateRange(
	        @Param("startPaydate") Date startPaydate,
	        @Param("endPaydate") Date endPaydate
	    );
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c WHERE p.paymentDate = :paymentDate")
	    List<Customers> findCustomersByPaymentDate(@Param("paymentDate") Date paymentDate);
	 
	 List<Payments> findByCustomer(Customers customer);
	 
		/*
		 * @Query("SELECT NEW com.example.dto.PaymentCustomerDTO(p, p.customer) " +
		 * "FROM Payments p " +
		 * "WHERE p.amount = (SELECT MAX(p2.amount) FROM Payments p2 WHERE p2.customer = p.customer)"
		 * ) PaymentCustomerDTO findCustomerWithMaxPaymentAmount();
		 */
	 
		/*
		 * @Query("SELECT NEW com.example.demo.dto.PaymentCustomerDTO(p, p.customer) " +
		 * "FROM Payments p " +
		 * "WHERE p.amount = (SELECT MAX(p2.amount) FROM Payments p2)")
		 * PaymentCustomerDTO findCustomerWithMaxPaymentAmount();
		 */


}
