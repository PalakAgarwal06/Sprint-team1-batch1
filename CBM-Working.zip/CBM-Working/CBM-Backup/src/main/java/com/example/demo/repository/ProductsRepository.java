package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.*;

import com.example.demo.dto.ProductNameSaleAmountDTO;
import com.example.demo.entities.Product;

public interface ProductsRepository extends JpaRepository<Product, String>{

	Product findByProductCode(String code);
	Product findByProductName(String name);
	
	
	 @Query("UPDATE Product p SET p.quantityInStock = :newQuantity WHERE p.productCode = :productCode")
	    void updateQuantityInStock(@Param("productCode") String productCode, @Param("newQuantity") Short newQuantity);
	 
	 
	 @Query("UPDATE Product p SET p.productName = :newName WHERE p.productCode = :productCode")
	    void updateProductName(@Param("productCode") String productCode, @Param("newName") String newName);
	 
	 @Query("SELECT p FROM Product p WHERE p.productName = :productName")
	    Product getProductByName(@Param("productName") String productName);
	 
	 
	 @Query("SELECT p FROM Product p WHERE UPPER(p.productScale) = UPPER(:productScale)")
	    List<Product> searchByProductScale(@Param("productScale") String productScale);
	 
	 @Query("SELECT p FROM Product p WHERE UPPER(p.productVendor) = UPPER(:productVendor)")
	    List<Product> searchByProductVendor(@Param("productVendor") String productVendor);
	 
	 @Query("SELECT NEW com.example.demo.dto.ProductNameSaleAmountDTO(p.productName, SUM(o.quantityOrdered * o.priceEach)) FROM OrderDetails o JOIN o.product p GROUP BY p.productName")
		List<ProductNameSaleAmountDTO> getTotalSaleAmountForEachProduct();
	 
	 @Query("SELECT SUM(o.quantityOrdered * o.priceEach) FROM OrderDetails o JOIN o.product p WHERE p.productCode = :productCode")
		double getTotalSaleAmountForGivenProductCode(@Param("productCode") String productCode);
	 
	 @Query("SELECT SUM(o.quantityOrdered) FROM OrderDetails o JOIN o.product p WHERE p.productCode = :productCode")
		int getTotalQuantityForGivenProductCode(@Param("productCode") String productCode);



}
