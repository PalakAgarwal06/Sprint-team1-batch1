package com.example.demo.services;

import com.example.demo.dto.OrderPaymentDetailsDto;
import com.example.demo.entities.*;

import com.example.demo.exception.CustomerNotFoundException;

import java.util.*;

public interface CustomerService {

	Customers getCustomerById(int customerNumber) throws CustomerNotFoundException;

	List<Customers> getAllCustomers();

	Customers createCustomer(Customers customers) throws CustomerNotFoundException;

	Customers updateCustomer(Customers customer) throws CustomerNotFoundException;

	void deleteCustomer(int customerNumber) throws CustomerNotFoundException;
	
	/*newly added methods*/
	
	List<Customers> searchCustomersByName(String name) throws CustomerNotFoundException;

	List<Customers> searchCustomersByCity(String city) throws CustomerNotFoundException;
	
	List<Customers> searchCustomersByAddressCity(String city) throws CustomerNotFoundException;
	
	List<Customers> searchByCountry(String country) throws CustomerNotFoundException;

	Customers searchByPhoneNumber(String phone) throws CustomerNotFoundException;

	Customers searchByContactFirstName(String firstName) throws CustomerNotFoundException;

	Customers searchByContactLastName(String lastName) throws CustomerNotFoundException;
	
	Customers updateCustomerName(int customerNumber, String newCustomerName)throws CustomerNotFoundException;
	
	Customers updateCustomerLastName (int customerNumber, String newCustomerLastName)throws CustomerNotFoundException ;
	
	Customers updateCustomerFirstName (int customerNumber, String newCustomerFirstName)throws CustomerNotFoundException ;
	
	Customers updateCustomerAddress (int customerNumber, String newCustomerAddress)throws CustomerNotFoundException ;
	
	List<Customers> searchCustomersByCreditLimit(double creditLimt) throws CustomerNotFoundException;

	List<Customers> searchCustomersByPostalCode(String postalCode) throws CustomerNotFoundException;
	
	List<Customers> searchByHighCreditLimit(double creditLimit);

	List<Customers> searchByLowCreditLimit(double creditLimit);
	
	List<Customers> getCustomersInCreditRange(double startCredit, double endCredit);
	
	//List<OrderPaymentDetailsDto> getOrderDetailAndPaymentForCustomer(String customerName);

	 List<OrderPaymentDetailsDto>getOrderPaymentDetailsForCustomer(String customerName);
}
