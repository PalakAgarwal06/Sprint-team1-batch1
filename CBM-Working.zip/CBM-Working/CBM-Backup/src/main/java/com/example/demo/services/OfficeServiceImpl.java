package com.example.demo.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Offices;

import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.OfficesRepository;

@Service
public class OfficeServiceImpl implements OfficeService {

	@Autowired
	OfficesRepository orepo;
	
	@Autowired
	EmployeeRepository employeeRepository;

	@Override

	public Offices createOffice(Offices office) {

		return orepo.save(office);

	}

	@Override

	public List<Offices> getAllOffices() {

		return orepo.findAll();

	}

	@Override

	public Offices updateOffices(Offices office) throws OfficeNotFoundException {

		if (orepo.findById(office.getCode()).isEmpty()) {

			throw new OfficeNotFoundException("Office with given id not found");

		}

		else {

			return orepo.save(office);

		}

	}

	@Override

	public Offices getOfficebyId(int code) throws OfficeNotFoundException {

		if (orepo.findById(code).isEmpty()) {

			throw new OfficeNotFoundException("Office with given id not found");

		}

		else {

			return orepo.findById(code).get();

		}

	}

	@Override

	public void deleteOffices(int code) throws OfficeNotFoundException {

		if (orepo.findById(code).isEmpty()) {

			throw new OfficeNotFoundException("Office with given id not found");

		}

		else {

			orepo.deleteById(code);

		}

	}

	@Override
	public Offices updatePhone(int code, String phone) throws OfficeNotFoundException {
		if (orepo.findById(code).isEmpty()) {

			throw new OfficeNotFoundException("Office with given id not found");

		}

		else {

			Offices offices = orepo.findById(code).get();
			offices.setPhone(phone);
			return orepo.save(offices);

		}

	}
	
	/*
	 * @Override public List<Offices> getOfficesByCities(List<String> cityNames)
	 * throws OfficeNotFoundException { if(orepo.findOfficesByCity(cityNames)==null)
	 * { throw new OfficeNotFoundException("Office with given id not found"); }
	 * return (List<Offices>)orepo.findOfficesByCity(cityNames); }
	 */
	
	@Override
	public Offices updateAddress(int code, String address) throws OfficeNotFoundException {
		if (orepo.findById(code).isEmpty()) {

			 

			throw new OfficeNotFoundException("Office with given id not found");

 

		}
		else{
			Offices offices = orepo.findById(code).get();
			offices.setAddressLine1(address);
			return orepo.save(offices);
		}
	}
	
	
	 public Offices createOfficeWithEmployees(Offices newOffice) {
	        // Create an Office object from the request data.
	        

	        // Save the office to the database.
	        Offices office = orepo.save(newOffice);

	        // Create and associate employees with the office.
	        List<Employees> employees = office.getEmployees();
	        for (Employees employee : employees) {
	            employee.setOffices(office);;
	            employeeRepository.save(employee);
	        }

	        return office;
	    }
	 @Override
	 public List<Customers> getAllCustomersOfofficeCode(int officeCode) {

			// TODO Auto-generated method stub

			return orepo.findCustomersByOfficeCode(officeCode);

		}

}