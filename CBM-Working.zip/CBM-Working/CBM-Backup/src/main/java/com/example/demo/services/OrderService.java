
  package com.example.demo.services;
  
  import java.util.Date;
import java.util.List; import com.example.demo.entities.Order; import
  com.example.demo.exception.OrderNotFoundException; import
  com.example.demo.entities.Order;
  
  
  
  public interface OrderService {
  
  Order createOrder(Order order); 
  List<Order> getAllOrder (Order order); 
  Order updateOrder (Order order) throws OrderNotFoundException; 
  Order getOrderById(int orderNumber) throws OrderNotFoundException;
  void deleteOrder(int orderNumber) throws OrderNotFoundException;
  
  Order updateOrderShippedDate(int orderNumber, Date shippedDate) throws OrderNotFoundException;
  List<Order> getOrdersByRequiredDate(Date requiredDate);
  List<Order> getOrdersByShippedDate(Date shippedDate);
  List<Order> getOrdersByStatus(String status);
  Order updateOrderStatus(int orderNumber, String status) throws OrderNotFoundException;
  
  }
 