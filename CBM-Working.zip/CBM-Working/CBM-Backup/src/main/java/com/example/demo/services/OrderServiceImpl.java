
  package com.example.demo.services;
  
  import java.util.Date;
import java.util.List;
  
  import org.springframework.beans.factory.annotation.Autowired; 
  import org.springframework.stereotype.Service;

import com.example.demo.entities.Employees;
import com.example.demo.entities.Order;
import com.example.demo.entities.Payments;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.OrderNotFoundException;
  
  import com.example.demo.repository.OrdersRepository;
  
  @Service 
  public class OrderServiceImpl implements OrderService {
  
  @Autowired 
  OrdersRepository orepo;
  
  @Override
  
  public Order createOrder(Order order) {
  
  return orepo.save(order);
  
  }
  
  @Override
  
  public List<Order> getAllOrder(Order order) {
  
  // TODO Auto-generated method stub
  
  return orepo.findAll();
  
  }
  
  @Override
  
  public Order updateOrder(Order order) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(order.getOrderNumber()).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  return orepo.save(order);
  
  }
  
  }
  
  @Override
  
  public Order getOrderById(int orderNumber) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(orderNumber).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  return orepo.findById(orderNumber).get();
  
  }
  
  }
  
  @Override
  
  public void deleteOrder(int orderNumber) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(orderNumber).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  orepo.deleteById(orderNumber);
  
  }
  
  }

@Override
public Order updateOrderShippedDate(int orderNumber, Date shippedDate) throws OrderNotFoundException {
	
	if(orepo.findById(orderNumber).isEmpty())
		  
		  throw new OrderNotFoundException("the order with" + orderNumber +
		  "does not exists");
		  
		  Order orders=orepo.findById(orderNumber).get();
		  
		  orders.setShippedDate(shippedDate);
		  
		  return orepo.save(orders);
		  
		  }
@Override
public List<Order> getOrdersByRequiredDate(Date requiredDate) {
    return orepo.findOrdersByRequiredDate(requiredDate);
}

@Override
public List<Order> getOrdersByShippedDate(Date shippedDate){
    return orepo.findOrdersByShippedDate(shippedDate);
}

@Override
public List<Order> getOrdersByStatus(String status) {
    return orepo.findOrdersByStatus(status);
}

@Override
public Order updateOrderStatus(int orderNumber, String status) throws OrderNotFoundException {
	if(orepo.findById(orderNumber).isEmpty())
		  
		  throw new OrderNotFoundException("the order with" + orderNumber +
		  "does not exists");
		  
		  Order orders=orepo.findById(orderNumber).get();
		  
		  orders.setStatus(status);
		  
		  return orepo.save(orders);
		  
		  }
	
}



 