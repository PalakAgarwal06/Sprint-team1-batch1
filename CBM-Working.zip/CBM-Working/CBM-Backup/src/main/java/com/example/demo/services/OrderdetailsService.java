package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.OrderDetails;

public interface OrderdetailsService {

	 OrderDetails addOrderDetails(OrderDetails orderDetails);
		/*
		 * OrderDetails updateQuantityOfOrderProduct(int orderNumber, String
		 * productCode, int quantityOrdered); List<OrderDetails> getByOrderNumber(int
		 * orderNumber); double getTotalAmountByOrderNumber(int orderNumber); int
		 * getByTotalSale(); double getOrderDetailsByMaxPriceOrder(); int
		 * getOrderDetailCountByOrderNumber(int orderNumber);
		 * 
		 * //extra for exceptions public OrderDetails getByOrderNumberAndProductCode(int
		 * orderNumber, String productCode);
		 */
	  List<OrderDetails> getByOrderNumber(int orderNumber);
}
