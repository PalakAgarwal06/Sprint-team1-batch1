package com.example.demo.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.OrderDetails;
import com.example.demo.repository.OrderdetailsRepository;

@Service
public class OrderdetailsServiceImpl implements OrderdetailsService {
	
	@Autowired
	private OrderdetailsRepository orderDetailRepo;
	
	

	@Override
	public OrderDetails addOrderDetails(OrderDetails orderDetails) {
		// TODO Auto-generated method stub
		return orderDetailRepo.save(orderDetails);
	}



	@Override
	public List<OrderDetails> getByOrderNumber(int orderNumber) {
		// TODO Auto-generated method stub
		return orderDetailRepo.findByOrderNumber(orderNumber);
	}

}
