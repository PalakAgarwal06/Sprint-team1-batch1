package com.example.demo.services;


import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Payments;
import com.example.demo.exception.PaymentsNotFoundException;

public interface PaymentsService {
	
	List<Payments> searchPaymentsByCheckNumber(String checkNumber) throws PaymentsNotFoundException;
	
	Double getTotalAmountByCustomerNumber(int customerNumber);
	
	public List<Payments> getPaymentsByPaymentDate(Date paymentDate) throws PaymentsNotFoundException;
	
	List<Customers> getCustomersByCheckNo(String checkno);
	
	//Customers getCustomerWithMaxPaymentAmount();
	
	List<Customers> getCustomersByPaymentDateRange(Date startPaydate, Date endPaydate);
	
	List<Customers> getCustomersByPaymentDate(Date paymentDate);
	
	List<Payments> findPaymentsByCustomer(Customers customer);
	
	Payments createPayment();

	PaymentCustomerDTO getCustomerWithMaxPaymentAmount();
	
	

}
