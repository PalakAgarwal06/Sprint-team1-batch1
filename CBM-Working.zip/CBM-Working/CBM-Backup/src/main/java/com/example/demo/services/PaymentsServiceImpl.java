package com.example.demo.services;


import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Payments;
import com.example.demo.repository.CustomersRepository;
import com.example.demo.repository.PaymentsRepository;

@Service
public class PaymentsServiceImpl implements PaymentsService{
	@Autowired
	PaymentsRepository paymentsRepository;
	
	@Autowired
	CustomersRepository customersRepository;

	public List<Payments> searchPaymentsByCheckNumber(String checkNumber) {
        return paymentsRepository.findByCheckNumber(checkNumber);
    }
	
	
	public List<Payments> getPaymentsByPaymentDate(Date paymentDate) {
        return paymentsRepository.findPaymentsByPaymentDate(paymentDate);
    }
	
	public Double getTotalAmountByCustomerNumber(int customerNumber) {
        return paymentsRepository.findTotalAmountByCustomerNumber(customerNumber);
    }
	
	public List<Customers> getCustomersByCheckNo(String checkno) {
        return paymentsRepository.findCustomersByCheckNo(checkno);
    }
	
	/*
	 * public Customers getCustomerWithMaxPaymentAmount() { return
	 * paymentsRepository.findCustomerWithMaxPaymentAmount();
	 * 
	 * }
	 */
	
	public List<Customers> getCustomersByPaymentDateRange(Date startPaydate, Date endPaydate) {
        return paymentsRepository.findCustomersByPaymentDateRange(startPaydate, endPaydate);
    }
	
	public List<Customers> getCustomersByPaymentDate(Date paymentDate) {
        return paymentsRepository.findCustomersByPaymentDate(paymentDate);
    }
	
	 public List<PaymentCustomerDTO> getPaymentDetailsForCustomer(int customer_id) {
	        Customers customer = customersRepository.findById(customer_id).orElse(null);
	        if (customer == null) {
	            // Handle customer not found
	            return Collections.emptyList();
	        }

	        List<Payments> payments = paymentsRepository.findByCustomer(customer);

	        List<PaymentCustomerDTO> paymentCustomerDTOs = payments.stream()
	            .map(payment -> new PaymentCustomerDTO(payment, customer))
	            .collect(Collectors.toList());

	        return paymentCustomerDTOs;
	    }
	 
	 public List<Payments> findPaymentsByCustomer(Customers customer) {
	        return paymentsRepository.findByCustomer(customer);
	    }


	@Override
	public Payments createPayment() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public PaymentCustomerDTO getCustomerWithMaxPaymentAmount() {
		// TODO Auto-generated method stub
		return paymentsRepository.findCustomerWithMaxPaymentAmount();
	}
	
	


	

}
