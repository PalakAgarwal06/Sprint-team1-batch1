package com.example.demo.controllertest;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.example.demo.controller.EmployeeController;
import com.example.demo.entities.Employees;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.services.EmployeesServiceImpl;
import com.example.demo.services.OfficeService;

//public class EmployeeControllerTest {
//
//    @Mock
//    private EmployeesServiceImpl employeeService;
//
//    @Mock
//    private OfficeService officeService;
//
//    @InjectMocks
//    private EmployeeController employeeController;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testGetAllEmployees() {
//        // Arrange
//        List<Employees> employeesList = new ArrayList<>();
//        when(employeeService.getAllEmployees()).thenReturn(employeesList);
//
//        // Act
//        ResponseEntity<List<Employees>> response = employeeController.getAllEmployees();
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(employeesList, response.getBody());
//    }
//
//    @Test
//    public void testGetEmployeeById() throws EmployeeNotFoundException {
//        // Arrange
//        int employeeNumber = 1;
//        Employees employee = new Employees();
//        when(employeeService.getEmployeeById(employeeNumber)).thenReturn(employee);
//
//        // Act
//        ResponseEntity<Employees> response = employeeController.getEmployeeById(employeeNumber);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(employee, response.getBody());
//    }
//
//    // Similar tests can be written for other controller methods
//
//    @Test
//    public void testAddEmployee() {
//        // Arrange
//        Employees employee = new Employees();
//        //doNothing().when(employeeService).createEmployee(employee);
//
//        // Act
//        ResponseEntity<Employees> response = employeeController.addEmployee(employee);
//
//        // Assert
//        assertEquals(HttpStatus.CREATED, response.getStatusCode());
//    }
//
//    @Test
//    public void testUpdateEmployeeRole() throws EmployeeNotFoundException {
//        // Arrange
//        int employeeId = 1;
//        String newRole = "New Role";
//        Employees updatedEmployee = new Employees();
//        when(employeeService.updateRole(employeeId, newRole)).thenReturn(updatedEmployee);
//
//        // Act
//        ResponseEntity<Employees> response = employeeController.updateEmployeeRole(employeeId, newRole);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(updatedEmployee, response.getBody());
//    }
//
//    // More tests for other methods can be added here
//}
