package com.example.demo.controllertest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import com.example.demo.controller.OfficeController;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.services.OfficeServiceImpl;

//public class OfficeControllerTest {
//
//    @Mock
//    private OfficeServiceImpl officeService;
//
//    @InjectMocks
//    private OfficeController officeController;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testGetAllOffices() {
//        // Arrange
//        List<Offices> officesList = new ArrayList<>();
//        when(officeService.getAllOffices()).thenReturn(officesList);
//
//        // Act
//        ResponseEntity<List<Offices>> response = officeController.getAllOffices();
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(officesList, response.getBody());
//    }
//
//    @Test
//    public void testGetOfficeById() throws OfficeNotFoundException {
//        // Arrange
//        int officeCode = 1;
//        Offices office = new Offices();
//        when(officeService.getOfficebyId(officeCode)).thenReturn(office);
//
//        // Act
//        ResponseEntity<Offices> response = officeController.getOfficeById(officeCode);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(office, response.getBody());
//    }
//
//    @Test
//    public void testUpdateOfficePhone() throws OfficeNotFoundException, EmployeeNotFoundException {
//        // Arrange
//        int officeCode = 1;
//        String phone = "123-456-7890";
//        Offices updatedOffice = new Offices();
//        when(officeService.updatePhone(officeCode, phone)).thenReturn(updatedOffice);
//
//        // Act
//        ResponseEntity<Offices> response = officeController.updateOfficePhone(officeCode, phone);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(updatedOffice, response.getBody());
//    }
//
//    // Similar tests can be written for other controller methods
//
//    @Test
//    public void testUpdateOfficeAddress() throws OfficeNotFoundException {
//        // Arrange
//        int officeCode = 1;
//        String address = "123 Main St";
//        Offices updatedOffice = new Offices();
//        when(officeService.updateAddress(officeCode, address)).thenReturn(updatedOffice);
//
//        // Act
//        ResponseEntity<Offices> response = officeController.updateOfficeAddress(officeCode, address);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(updatedOffice, response.getBody());
//    }
//
//    @Test
//    public void testCreateOfficeWithEmployees() {
//        // Arrange
//        Offices office = new Offices();
//        when(officeService.createOfficeWithEmployees(office)).thenReturn(office);
//
//        // Act
//        ResponseEntity<String> response = officeController.createOfficeWithEmployees(office);
//
//        // Assert
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//    }
//
//    @Test
//    public void testGetAllCustomersOfOfficeCode() {
//        // Arrange
//        int officeCode = 1;
//        List<Customers> customersList = new ArrayList<>();
//        when(officeService.getAllCustomersOfofficeCode(officeCode)).thenReturn(customersList);
//
//        // Act
//        List<Customers> result = officeController.getAllCustomersOfofficeCode(officeCode);
//
//        // Assert
//        assertEquals(customersList, result);
//    }
//
//    // More tests for other methods can be added here
//}
