package com.example.demo.controllertest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.demo.controller.ProductLineController;
import com.example.demo.entities.ProductLine;
import com.example.demo.exception.ProductLineNotFoundException;
import com.example.demo.services.ProductLineServiceImpl;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

//public class ProductLineControllerTest {
//
//    @Mock
//    private ProductLineServiceImpl productLineService;
//
//    @InjectMocks
//    private ProductLineController productLineController;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testCreateProductLine() {
//        // Arrange
//        ProductLine productLine = new ProductLine();
//        when(productLineService.createProductLine(productLine)).thenReturn(productLine);
//
//        // Act
//        ResponseEntity<ProductLine> response = productLineController.createProductLine(productLine);
//
//        // Assert
//        assertNotNull(response);
//        assertEquals(HttpStatus.CREATED, response.getStatusCode());
//        assertEquals(productLine, response.getBody());
//    }
//
//    @Test
//    public void testUpdateProductLineDescription() throws ProductLineNotFoundException {
//        // Arrange
//        String productLineId = "testProductLine";
//        String textDescription = "Test Description";
//        ProductLine updatedProductLine = new ProductLine();
//        when(productLineService.updateProductLineDescription(productLineId, textDescription)).thenReturn(updatedProductLine);
//
//        // Act
//        ResponseEntity<ProductLine> response = productLineController.updateProductLineDescription(productLineId, textDescription);
//
//        // Assert
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(updatedProductLine, response.getBody());
//    }
//
//    @Test
//    public void testGetProductById() throws ProductLineNotFoundException {
//        // Arrange
//        String productLineId = "testProductLine";
//        ProductLine productLine = new ProductLine();
//        when(productLineService.getProductLineById(productLineId)).thenReturn(productLine);
//
//        // Act
//        ResponseEntity<ProductLine> response = productLineController.getProductById(productLineId);
//
//        // Assert
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(productLine, response.getBody());
//    }
//
//    @Test
//    public void testGetAllProductLine() throws ProductLineNotFoundException {
//        // Arrange
//        List<ProductLine> productLines = new ArrayList<>();
//        when(productLineService.getAllProductLine()).thenReturn(productLines);
//
//        // Act
//        ResponseEntity<List<ProductLine>> response = productLineController.getAllProductLine();
//
//        // Assert
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(productLines, response.getBody());
//    }
//
//    @Test
//    public void testDeleteProductLine() throws ProductLineNotFoundException {
//        // Arrange
//        String productLineId = "testProductLine";
//
//        // Act
//        ResponseEntity<String> response = productLineController.deleteProductLine(productLineId);
//
//        // Assert
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals("ProductLine deleted", response.getBody());
//        verify(productLineService, times(1)).deleteProductLine(productLineId);
//    }
//}
