package com.example.demo.servicetest;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.example.demo.entities.Employees;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.services.EmployeesServiceImpl;

//public class EmployeesServiceImplTest {
//
//    @Mock
//    private EmployeeRepository employeeRepository;
//
//    @InjectMocks
//    private EmployeesServiceImpl employeesService;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testGetEmployeeById() throws EmployeeNotFoundException {
//        // Arrange
//        int employeeNumber = 1;
//        Employees employee = new Employees();
//        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.of(employee));
//
//        // Act
//        Employees result = employeesService.getEmployeeById(employeeNumber);
//
//        // Assert
//        assertEquals(employee, result);
//    }
//
//    @Test
//    public void testGetEmployeeByIdNotFound() {
//        // Arrange
//        int employeeNumber = 1;
//        when(employeeRepository.findById(employeeNumber)).thenReturn(Optional.empty());
//
//        // Act & Assert
//        assertThrows(EmployeeNotFoundException.class, () -> employeesService.getEmployeeById(employeeNumber));
//    }
//
//    @Test
//    public void testGetAllEmployees() {
//        // Arrange
//        List<Employees> employeesList = new ArrayList<>();
//        when(employeeRepository.findAll()).thenReturn(employeesList);
//
//        // Act
//        List<Employees> result = employeesService.getAllEmployees();
//
//        // Assert
//        assertEquals(employeesList, result);
//    }
//
//    @Test
//    public void testCreateEmployee() {
//        // Arrange
//        Employees employee = new Employees();
//        when(employeeRepository.save(employee)).thenReturn(employee);
//
//        // Act
//        Employees result = employeesService.createEmployee(employee);
//
//        // Assert
//        assertEquals(employee, result);
//    }
//
//    @Test
//    public void testUpdateEmployee() throws EmployeeNotFoundException {
//        // Arrange
//        Employees employee = new Employees();
//        when(employeeRepository.findById(employee.getEmployeeNumber())).thenReturn(Optional.of(employee));
//        when(employeeRepository.save(employee)).thenReturn(employee);
//
//        // Act
//        Employees result = employeesService.updateEmployee(employee);
//
//        // Assert
//        assertEquals(employee, result);
//    }
//
//    @Test
//    public void testUpdateEmployeeNotFound() {
//        // Arrange
//        Employees employee = new Employees();
//        when(employeeRepository.findById(employee.getEmployeeNumber())).thenReturn(Optional.empty());
//
//        // Act & Assert
//        assertThrows(EmployeeNotFoundException.class, () -> employeesService.updateEmployee(employee));
//    }
//
//    // Similar tests can be written for other methods
//
//}
