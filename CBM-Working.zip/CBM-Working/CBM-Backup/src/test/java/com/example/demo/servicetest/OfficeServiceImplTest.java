package com.example.demo.servicetest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Offices;
import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.repository.EmployeeRepository;
import com.example.demo.repository.OfficesRepository;
import com.example.demo.services.OfficeServiceImpl;

//public class OfficeServiceImplTest {
//
//    @Mock
//    private OfficesRepository orepo;
//
//    @Mock
//    private EmployeeRepository employeeRepository;
//
//    @InjectMocks
//    private OfficeServiceImpl officeService;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testCreateOffice() {
//        // Arrange
//        Offices office = new Offices();
//        when(orepo.save(office)).thenReturn(office);
//
//        // Act
//        Offices createdOffice = officeService.createOffice(office);
//
//        // Assert
//        assertEquals(office, createdOffice);
//    }
//
//    @Test
//    public void testGetAllOffices() {
//        // Arrange
//        List<Offices> officesList = new ArrayList<>();
//        when(orepo.findAll()).thenReturn(officesList);
//
//        // Act
//        List<Offices> result = officeService.getAllOffices();
//
//        // Assert
//        assertEquals(officesList, result);
//    }
//
//    @Test
//    public void testUpdateOffices() throws OfficeNotFoundException {
//        // Arrange
//        Offices office = new Offices();
//        when(orepo.findById(office.getCode())).thenReturn(Optional.of(office));
//        when(orepo.save(office)).thenReturn(office);
//
//        // Act
//        Offices updatedOffice = officeService.updateOffices(office);
//
//        // Assert
//        assertEquals(office, updatedOffice);
//    }
//
//    @Test
//    public void testUpdateOfficesNotFound() {
//        // Arrange
//        Offices office = new Offices();
//        when(orepo.findById(office.getCode())).thenReturn(Optional.empty());
//
//        // Act & Assert
//        assertThrows(OfficeNotFoundException.class, () -> officeService.updateOffices(office));
//    }
//
//    // Similar tests can be written for other methods
//
//    @Test
//    public void testCreateOfficeWithEmployees() {
//        // Arrange
//        Offices newOffice = new Offices();
//        when(orepo.save(newOffice)).thenReturn(newOffice);
//
//        Employees employee1 = new Employees();
//        Employees employee2 = new Employees();
//        List<Employees> employees = new ArrayList<>();
//        employees.add(employee1);
//        employees.add(employee2);
//        newOffice.setEmployees(employees);
//
//        // Act
//        Offices createdOffice = officeService.createOfficeWithEmployees(newOffice);
//
//        // Assert
//        assertEquals(newOffice, createdOffice);
//        verify(employeeRepository, times(2)).save(any(Employees.class));
//    }
//
//    @Test
//    public void testGetAllCustomersOfOfficeCode() {
//        // Arrange
//        int officeCode = 1;
//        List<Customers> customersList = new ArrayList<>();
//        when(orepo.findCustomersByOfficeCode(officeCode)).thenReturn(customersList);
//
//        // Act
//        List<Customers> result = officeService.getAllCustomersOfofficeCode(officeCode);
//
//        // Assert
//        assertEquals(customersList, result);
//    }
//
//    // More tests for other methods can be added here
//}
