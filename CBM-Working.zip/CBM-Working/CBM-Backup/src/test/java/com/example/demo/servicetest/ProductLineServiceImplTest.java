package com.example.demo.servicetest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.example.demo.entities.ProductLine;
import com.example.demo.exception.ProductLineNotFoundException;
import com.example.demo.repository.ProductlinesRepository;
import com.example.demo.services.ProductLineServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

//public class ProductLineServiceImplTest {
//
//    @Mock
//    private ProductlinesRepository productLineRepo;
//
//    @InjectMocks
//    private ProductLineServiceImpl productLineService;
//
//    @BeforeEach
//    public void setup() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testCreateProductLine() {
//        // Arrange
//        ProductLine productLine = new ProductLine();
//        when(productLineRepo.save(productLine)).thenReturn(productLine);
//
//        // Act
//        ProductLine createdProductLine = productLineService.createProductLine(productLine);
//
//        // Assert
//        assertNotNull(createdProductLine);
//        assertEquals(productLine, createdProductLine);
//    }
//
//    @Test
//    public void testGetAllProductLine() {
//        // Arrange
//        List<ProductLine> productLines = new ArrayList<>();
//        when(productLineRepo.findAll()).thenReturn(productLines);
//
//        // Act
//        List<ProductLine> result = productLineService.getAllProductLine();
//
//        // Assert
//        assertEquals(productLines, result);
//    }
//
//    @Test
//    public void testUpdateProductLine() throws ProductLineNotFoundException {
//        // Arrange
//        ProductLine productLine = new ProductLine();
//        when(productLineRepo.findById(productLine.getProductLine())).thenReturn(Optional.of(productLine));
//        when(productLineRepo.save(productLine)).thenReturn(productLine);
//
//        // Act
//        ProductLine updatedProductLine = productLineService.updateProductLine(productLine);
//
//        // Assert
//        assertNotNull(updatedProductLine);
//        assertEquals(productLine, updatedProductLine);
//    }
//
//    @Test
//    public void testUpdateProductLineNotFound() {
//        // Arrange
//        ProductLine productLine = new ProductLine();
//        when(productLineRepo.findById(productLine.getProductLine())).thenReturn(Optional.empty());
//
//        // Act & Assert
//        assertThrows(ProductLineNotFoundException.class, () -> productLineService.updateProductLine(productLine));
//    }
//
//    // Add similar tests for other methods like getProductLineById, deleteProductLine, and updateProductLineDescription.
//
//}
