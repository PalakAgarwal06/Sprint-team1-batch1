package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Offices;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.OfficeNotFoundException;
import com.example.demo.services.OfficeService;
import com.example.demo.services.OfficeServiceImpl;

 

@RestController

@RequestMapping("/api/v1/office")

 

public class OfficeController {

	



	private final OfficeServiceImpl officeService;
	
	@Autowired
	public OfficeController(OfficeServiceImpl officeService) {
        this.officeService = officeService;
    }
	
	@GetMapping("/")

	public ResponseEntity<List<Offices>> getAllOffices(){

		return new ResponseEntity<List<Offices>>(officeService.getAllOffices(),HttpStatus.OK);

		

		}

	
	
	@GetMapping("/{code}")
	public ResponseEntity<Offices> getOfficeById(@PathVariable("code") int code) throws OfficeNotFoundException{
		return new ResponseEntity<Offices> (officeService.getOfficebyId(code),HttpStatus.OK);

	}
	
	@PutMapping("/{office_code}/{phone}")
    public ResponseEntity<Offices> updateOfficePhone(@PathVariable("office_code") int code, @PathVariable String phone ) throws EmployeeNotFoundException, OfficeNotFoundException {
        return new ResponseEntity<Offices>(officeService.updatePhone(code, phone),HttpStatus.OK);
 }
	
	/*
	 * @GetMapping("/{city1}/{city2}/{cityN}") public ResponseEntity<List<Offices>>
	 * getOfficeByCities(@PathVariable("city") List<String> cityNames) throws
	 * OfficeNotFoundException{ return new ResponseEntity<List<Offices>>
	 * (officeService.getOfficesByCities(cityNames),HttpStatus.OK);
	 * 
	 * }
	 */
	
	@PutMapping("/{office_code}/address")
    public ResponseEntity<Offices> updateOfficeAddress(@PathVariable("office_code") int code,@RequestParam String address ) throws OfficeNotFoundException {
        return new ResponseEntity<Offices>(officeService.updateAddress(code, address),HttpStatus.OK);
 }
	
	@GetMapping("/cities/{cities}")
    public List<Offices> getOfficesByCities(@PathVariable List<String> cities) {
        return officeService.getOfficesByCities(cities);
    }
	
	@PostMapping("/")
    public ResponseEntity<String> createOfficeWithEmployees(@RequestBody Offices office) {
        System.out.println(office);
        Offices createdOffice = officeService.createOfficeWithEmployees(office);

        return new ResponseEntity<String>("office created",HttpStatus.OK);
    }
	
	@GetMapping("/customers/{officeCode}")

	public List<Customers> getAllCustomersOfofficeCode(@PathVariable int officeCode){

		return officeService.getAllCustomersOfofficeCode(officeCode);

	}
	
	
}
