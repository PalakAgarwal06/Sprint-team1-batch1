package com.example.demo.controller;

 

import java.util.List;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.OrderDetailDTO;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Order;
import com.example.demo.entities.OrderDetails;
import com.example.demo.exception.OrderNotFoundException;
import com.example.demo.services.OrderService;
import com.example.demo.services.OrderDetailsService;

 

@RestController
@RequestMapping("/api/v1/orderdetails")
public class OrderDetailsController {

 

	@Autowired
	OrderService orderService;

	@Autowired
	private OrderDetailsService service;

	@PostMapping("/")
    public ResponseEntity<String> addOrderDetails(@RequestBody OrderDetailDTO orderDetailsDTO) throws Exception {
        service.addOrderDetails(orderDetailsDTO);
        return ResponseEntity.ok("Record Created Successfully");
    }

	@GetMapping("/{orderNumber}")
	public ResponseEntity<?> getByOrderNumber(@PathVariable int orderNumber) {
		List<OrderDetails> orderDetails = service.getByOrderNumber(orderNumber);
		if(!orderDetails.isEmpty()) {
			return new ResponseEntity<>(orderDetails, HttpStatus.OK);
		}
		return new ResponseEntity<>("not found ", HttpStatus.INTERNAL_SERVER_ERROR);
		}

	@GetMapping("/max/price")
	public ResponseEntity<Double> getMaxPriceOrderDetail() {
		double maxPrice = service.getOrderDetailsByMaxPriceOrder();
		return ResponseEntity.ok(maxPrice);
	}

	@GetMapping("/countByOrderNumber/{orderNumber}")
	public ResponseEntity<Integer> getOrderDetailCountByOrderNumber(@PathVariable("orderNumber") int orderNumber) {
		int count = service.getOrderDetailCountByOrderNumber(orderNumber);
		return ResponseEntity.ok(count);
	}
	
	@GetMapping("/total_specific/{orderNumber}")
	public ResponseEntity<String> getTotalOrderAmount(@PathVariable int orderNumber) {
        Double totalAmount = service.getTotalOrderAmount(orderNumber);

        if (totalAmount == null) {
            // Handle the case where the order is not found or has no details
            return new ResponseEntity<>("Specific order total amount not found", HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>("Specific order total amount: " + totalAmount, HttpStatus.OK);
    }
	
	@GetMapping("/total_sale")
    public ResponseEntity<String> getTotalSale() {
        Double totalSale = service.getTotalSale();

        if (totalSale == null) {
            // Handle the case where the total sale is not available
            return new ResponseEntity<>("Total sale not available", HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>("Total sale done: " + totalSale, HttpStatus.OK);
    }
	
	@PutMapping("/{orderNumber}/{productCode}/{quantityOrdered}")
    public ResponseEntity<String> updateQuantityOrdered(
            @PathVariable("orderNumber") int orderNumber,
            @PathVariable("productCode") String productCode,
            @PathVariable("quantityOrdered") int quantityOrdered) {

        String message = service.updateQuantityOrdered(orderNumber, productCode, quantityOrdered);

        if ("Product Quantity updated successfully".equals(message)) {
            return new ResponseEntity<>(message, HttpStatus.OK);
        }

        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }






}