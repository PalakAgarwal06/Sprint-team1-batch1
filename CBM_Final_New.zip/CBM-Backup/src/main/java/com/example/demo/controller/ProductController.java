package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.ProductDTO;
import com.example.demo.entities.Product;
import com.example.demo.exception.ProductNotFoundException;
import com.example.demo.services.ProductService;
import com.example.demo.services.ProductServiceImpl;

 

@RestController

@RequestMapping("/api/v1/products")

 

public class ProductController {

	



	private final ProductServiceImpl productService;
	
	@Autowired
	public ProductController(ProductServiceImpl productService) {
        this.productService = productService;
    }
	
	@PostMapping("/create")
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product createdProduct = productService.createProduct(product);
        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
    }
	
	@PutMapping("update/{product_code}/{quantity_in_stock}")
    public ResponseEntity<String> updateQuantityInStock(
        @PathVariable("product_code") String productCode,
        @PathVariable("quantity_in_stock") int newQuantity
    ) {
        try {
            productService.updateQuantityInStock(productCode, newQuantity);
            return new ResponseEntity<>("Quantity in stock updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/name/{product_name}")
    public ResponseEntity<String> updateProductName(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_name") String newName
    ) {
        try {
            productService.updateProductName(productCode, newName);
            return new ResponseEntity<>("Product name updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/scale/{product_scale}")
    public ResponseEntity<String> updateProductScale(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_scale") String newScale
    ) {
        try {
            productService.updateProductScale(productCode, newScale);
            return new ResponseEntity<>("Product Scale updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/vendor/{product_vendor}")
    public ResponseEntity<String> updateProductVendor(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_vendor") String newVendor
    ) {
        try {
            productService.updateProductVendor(productCode, newVendor);
            return new ResponseEntity<>("Product Vendor updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/msrp/{product_msrp}")
    public ResponseEntity<String> updateProductMSRP(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_msrp") double newMSRP
    ) {
        try {
            productService.updateProductMSRP(productCode, newMSRP);
            return new ResponseEntity<>("Product MSRP updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@PutMapping("/{productCode}/buy_price/{product_buyPrice}")
    public ResponseEntity<String> updateProductBuyPrice(
        @PathVariable("productCode") String productCode,
        @PathVariable("product_buyPrice") double newBuyPrice
    ) {
        try {
            productService.updateProductBuyPrice(productCode, newBuyPrice);
            return new ResponseEntity<>("Product MSRP updated successfully", HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/{productCode}")
    public ResponseEntity<?> getProductById(@PathVariable("productCode") String productCode) {
        try {
            Product product = productService.getProductById(productCode);
            return new ResponseEntity<>(product, HttpStatus.OK);
        } catch (ProductNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/product_name/{product_name}")
    public ResponseEntity<?> getProductByName(@PathVariable("product_name") String productName) {
        try {
            Product product = productService.getProductByName(productName);
            if (product != null) {
                return new ResponseEntity<>(product, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	@GetMapping("/product_scale/{product_scale}")
    public ResponseEntity<?> searchByProductScale(@PathVariable("product_scale") String productScale) {
        try {
            List<Product> productList = productService.searchByProductScale(productScale);
            if (!productList.isEmpty()) {
                return new ResponseEntity<>(productList, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("No products found with the specified scale", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    
	@GetMapping("/product_vendor/{product_vendor}")
    public ResponseEntity<?> searchByProductVendor(@PathVariable("product_vendor") String productVendor) {
        try {
            List<Product> productList = productService.searchByProductVendor(productVendor);
            if (!productList.isEmpty()) {
                return new ResponseEntity<>(productList, HttpStatus.OK);
            } else {
                return new ResponseEntity<>("No products found for the specified vendor", HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
	
	 @GetMapping("/product_details")
	    public ResponseEntity<List<ProductDTO>> getHighlyDemandedProducts() {
	        List<ProductDTO> highlyDemandedProducts = productService.getHighlyDemandedProducts();
	        return new ResponseEntity<>(highlyDemandedProducts, HttpStatus.OK);
	    }
}








