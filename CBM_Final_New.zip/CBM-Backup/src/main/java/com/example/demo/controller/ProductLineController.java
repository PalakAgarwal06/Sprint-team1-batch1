package com.example.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Employees;
import com.example.demo.entities.ProductLine;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.ProductLineNotFoundException;
import com.example.demo.services.ProductLineService;
import com.example.demo.services.ProductLineServiceImpl;

 

@RestController

@RequestMapping("/api/v1/product_lines")

 

public class ProductLineController {

	



	private final ProductLineServiceImpl productLineService;
	
	@Autowired
	public ProductLineController(ProductLineServiceImpl productLineService) {
        this.productLineService = productLineService;
    }
	
	 @PostMapping("/create")
	    public ResponseEntity<ProductLine> createProductLine(@RequestBody ProductLine productLine) {
	        ProductLine createdProductLine = productLineService.createProductLine(productLine);
	        return new ResponseEntity<>(createdProductLine, HttpStatus.CREATED);
	    }
	
	@PutMapping("/product_line /{product_line}/text_description/ {text_description}")
    public ResponseEntity<ProductLine> updateEmployeeRole(@PathVariable("product_line") String product_line, @PathVariable("text_description") String text_description) throws ProductLineNotFoundException {
        return new ResponseEntity<ProductLine>(productLineService.updateProductLineDescription(product_line, text_description),HttpStatus.OK);
 }
	
	@GetMapping("/{product_line}")

	public ResponseEntity <ProductLine> getProductById(@PathVariable("product_line")String product_line) throws ProductLineNotFoundException{

		return new ResponseEntity<ProductLine>(productLineService.getProductLineById(product_line),HttpStatus.OK);

		

		}
}
