package com.example.demo.dto;

public class ProductLineDTO {
	private String productName;
    private String productLine;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductLine() {
		return productLine;
	}
	public ProductLineDTO(String productName, String productLine) {
		super();
		this.productName = productName;
		this.productLine = productLine;
	}
	public void setProductLine(String productLine) {
		this.productLine = productLine;
	}

}
