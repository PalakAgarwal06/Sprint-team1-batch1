 package com.example.demo.entities;
import java.io.Serializable;
import java.util.Objects;

public class OrderDetailsId implements Serializable {

    private String product;  // Replace with the actual type of 'Product' entity ID
    private int orders;   // Replace with the actual type of 'Order' entity ID

    // Implement equals and hashCode methods

    public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public int getOrders() {
		return orders;
	}

	public void setOrders(int orders) {
		this.orders = orders;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof OrderDetailsId)) return false;
        OrderDetailsId that = (OrderDetailsId) o;
        return Objects.equals(product, that.product) &&
                Objects.equals(orders, that.orders);
    }

    @Override
    public int hashCode() {
        return Objects.hash(product, orders);
    }
}
