package com.example.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import

org.springframework.data.jpa.repository.Modifying;
import

org.springframework.data.jpa.repository.Query;
import

org.springframework.data.repository.query.Param;

import com.example.demo.dto.OrderPaymentDetailsDto;

import com.example.demo.entities.OrderDetails;

public interface OrderDetailsRepository extends JpaRepository<OrderDetails,

		Integer> {

	/*
	 * 
	 * List<OrderDetails> findByPriceEachEqualsOrderByPriceEachDesc(Double
	 * 
	 * maxPrice); Double findMaxPrice();
	 *
	 *
	 * 
	 * 
	 * 
	 * @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od")
	 * 
	 * Double getTotalSale();
	 *
	 * 
	 * 
	 * @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od WHERE od.order.orderNumber = :orderNumber"
	 * 
	 * ) Double calculateTotalAmountByOrderNumber(@Param("orderNumber") Integer
	 * 
	 * orderNumber);
	 *
	 *
	 * 
	 * 
	 * 
	 * @Modifying
	 *
	 * 
	 * 
	 * @Transactional
	 *
	 * 
	 * 
	 * @Query("UPDATE OrderDetails od " + "SET od.quantityOrdered = :newQuantity " +
	 * 
	 * "WHERE od.order.orderNumber = :orderNumber " +
	 * 
	 * "AND od.product.productCode = :productCode") void
	 * 
	 * updateQuantityOrdered(Integer orderNumber, String productCode, Integer
	 * 
	 * newQuantity); List<OrderDetails> findByOrderOrderNumber(Integer orderNumber);
	 *
	 * 
	 * 
	 * @Query("SELECT od FROM OrderDetails od WHERE od.order.orderNumber = :orderNumber"
	 * 
	 * ) List<OrderDetails> findByOrderNumber(@Param("orderNumber") Integer
	 * 
	 * orderNumber);
	 *
	 * 
	 * 
	 * @Query("SELECT COUNT(od) FROM OrderDetail od WHERE od.attribute = :attribute"
	 * 
	 * ) Long countOrderDetailsByAttribute(@Param("attribute") String attribute);
	 *
	 * 
	 * 
	 */

	@Query("SELECT NEW com.example.demo.dto.OrderPaymentDetailsDto(od, p) " +

			"FROM OrderDetails od " +

			"JOIN od.orders o " +

			"JOIN o.customer c " +

			"JOIN c.payment p " +

			"WHERE c.customerName = :customerName")

	List<OrderPaymentDetailsDto> findOrderPaymentDetailsByCustomerName(@Param("customerName") String customerName);

	@Query("SELECT od FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")

	List<OrderDetails> findByOrderNumber(@Param("orderNumber") int orderNumber);

	@Query

	("SELECT MAX(od.priceEach) FROM OrderDetails od")

	double getMaxPriceForOrder();

	@Query

	("SELECT COUNT(od) FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")

	int getOrderDetailCountByOrderNumber(@Param("orderNumber") int orderNumber);
	
	 @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od WHERE od.orders.orderNumber = :orderNumber")
	    Double getTotalOrderAmount(@Param("orderNumber") int orderNumber);
	 
	 @Query("SELECT SUM(od.quantityOrdered * od.priceEach) FROM OrderDetails od")
	    Double getTotalSale();
	 
	 @Modifying
	    @Transactional
	    @Query("UPDATE OrderDetails od SET od.quantityOrdered = :quantityOrdered WHERE od.orders.orderNumber = :orderNumber AND od.product.productCode = :productCode")
	    int updateQuantityOrdered(@Param("orderNumber") int orderNumber, @Param("productCode") String productCode, @Param("quantityOrdered") int quantityOrdered);

}
