package com.example.demo.repository;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dto.PaymentCustomerDTO;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.entities.Payments;

public interface PaymentsRepository extends JpaRepository<Payments, String> {
	
	List<Payments> findByCheckNumber(String checkNumber);
	
	
	
	@Query("SELECT p FROM Payments p WHERE p.paymentDate = :paymentDate")

    List<Payments> findPaymentsByPaymentDate(@Param("paymentDate") Date paymentDate);
	
	 @Query("SELECT SUM(p.amount) FROM Payments p WHERE p.customer.customerNumber = :customerNumber")
	 Double findTotalAmountByCustomerNumber(@Param("customerNumber") int customerNumber);
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c " +
	           "WHERE p.checkNumber = :checkNumber")
	    List<Customers> findCustomersByCheckNo(@Param("checkNumber") String checkNumber);
	 
	 @Query("SELECT c FROM Payments p JOIN p.customer c " +
	           "GROUP BY c.customerNumber " +
	           "ORDER BY MAX(p.amount)")
	    Customers findCustomerWithMaxPaymentAmount();
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c " +
	           "WHERE p.paymentDate BETWEEN :startPaydate AND :endPaydate")
	    List<Customers> findCustomersByPaymentDateRange(
	        @Param("startPaydate") Date startPaydate,
	        @Param("endPaydate") Date endPaydate
	    );
	 
	 @Query("SELECT DISTINCT c FROM Payments p JOIN p.customer c WHERE p.paymentDate = :paymentDate")
	    List<Customers> findCustomersByPaymentDate(@Param("paymentDate") Date paymentDate);
	 
	 @Modifying
	 @Transactional
	    @Query("UPDATE Payments p SET p.checkNumber = :newCheckNumber WHERE p.customer.customerNumber = :customerNumber AND p.checkNumber = :checkNumber")
	    int updateCheckNumberForPayment(
	        @Param("customerNumber") int customerNumber,
	        @Param("checkNumber") String checkNumber,
	        @Param("newCheckNumber") String newCheckNumber
	    );
	 
	 @Modifying
	 @Transactional
	    @Query("UPDATE Payments p SET p.amount = :newAmount WHERE p.customer.customerNumber = :customerNumber AND p.checkNumber = :checkNumber")
	    int updatePaymentAmountForCheck(
	        @Param("customerNumber") int customerNumber,
	        @Param("checkNumber") String checkNumber,
	        @Param("newAmount") Double newAmount
	    );
	 
	 @Query("SELECT p FROM Payments p WHERE p.customer.customerNumber = :customerNumber")
	    List<Payments> findPaymentsByCustomerNumber(@Param("customerNumber") int customerNumber);
	 
	 List<Payments> findByCustomer(Customers customer);
	 
	 
	 
	 @Query("SELECT p.customer.customerNumber, SUM(p.amount) " +
	           "FROM Payments p " +
	           "GROUP BY p.customer.customerNumber " +
	           "ORDER BY SUM(p.amount) DESC")
	    List<Object[]> findCustomerTotalPayments();
	    @Query("SELECT o FROM Offices o WHERE o.code = :officeCode")
	    Offices findOfficeByCode(@Param("officeCode") int officeCode);
	    Payments findTopByCustomerOrderByAmountDesc(Customers customer);

	    default List<Offices> findOfficeWithMaxPaymentCollection() {
	        List<Object[]> customerTotalPayments = findCustomerTotalPayments();
	        if (!customerTotalPayments.isEmpty()) {
	            Object[] maxPaymentCustomer = customerTotalPayments.get(0);
	            int customerNumber = (int) maxPaymentCustomer[0];
	            Customers customer = new Customers();
	            customer.setCustomerNumber(customerNumber);
	            
	            // Use 'this' to reference the current repository
	            Payments maxPayment = this.findTopByCustomerOrderByAmountDesc(customer);
	            
	            if (maxPayment != null) {
	                int officeCode = maxPayment.getCustomer().getEmployeeRep().getOffices().getCode();
	                return Collections.singletonList(findOfficeByCode(officeCode));
	            }
	        }
	        return Collections.emptyList();
	    }
	





	 


}
