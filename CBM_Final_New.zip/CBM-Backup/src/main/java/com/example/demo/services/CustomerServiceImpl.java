package com.example.demo.services;

import java.util.List;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 

import com.example.demo.dto.OrderPaymentDetailsDto;
import com.example.demo.entities.Customers;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Payments;
import com.example.demo.exception.CustomerNotFoundException;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.repository.CustomersRepository;
import com.example.demo.repository.OrderDetailsRepository;
import com.example.demo.repository.PaymentsRepository;

 

@Service
public class CustomerServiceImpl implements CustomerService {

 

	@Autowired
	CustomersRepository customerRepository;

	@Autowired
	OrderDetailsRepository orderDetailsRepository;
	
	@Autowired
	PaymentsRepository paymentRepository;

 

	@Override
	public Customers getCustomerById(int customerNumber) throws CustomerNotFoundException {

 

		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("The Customer with" + customerNumber + "does not exist");

 

		return customerRepository.findById(customerNumber).get();

 

	}

 

	@Override
	public List<Customers> getAllCustomers() {

 

		return customerRepository.findAll();

 

	}

 

	@Override

 

	public Customers createCustomer(Customers customers) throws CustomerNotFoundException {

 

		return customerRepository.save(customers);

 

	}

 

	@Override

 

	public Customers updateCustomer(Customers customer) throws CustomerNotFoundException {

 

		if (customerRepository.findById(customer.getCustomerNumber()).isEmpty())

 

			throw new CustomerNotFoundException("The Customer with" + customer.getCustomerNumber() + "does not exists");

 

		return customerRepository.save(customer);

 

	}

 

	@Override

 

	public void deleteCustomer(int customerNumber) throws CustomerNotFoundException {

 

		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("the Customer with" + customerNumber + "does not exists");

 

		customerRepository.delete(customerRepository.findById(customerNumber).get());

 

	}

 

	@Override
	public List<Customers> searchCustomersByName(String name) throws CustomerNotFoundException {
		if (customerRepository.findByCustomerName(name) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}
		return customerRepository.findByCustomerName(name);
	}

 

	@Override
	public List<Customers> searchCustomersByCity(String city) throws CustomerNotFoundException {
		if (customerRepository.findByCity(city) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findByCity(city);
	}

 

	@Override
	public List<Customers> searchCustomersByAddressCity(String city) throws CustomerNotFoundException {
		if (customerRepository.findCustomersByCity(city) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findCustomersByCity(city);
	}

 

	@Override
	public List<Customers> searchByCountry(String country) throws CustomerNotFoundException {
		if (customerRepository.findByCountry(country) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findByCountry(country);
	}

 

	@Override
	public Customers searchByPhoneNumber(String phone) throws CustomerNotFoundException {
		if (customerRepository.findByPhone(phone) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findByPhone(phone);
	}

 

	@Override
	public Customers searchByContactFirstName(String firstName) throws CustomerNotFoundException {
		if (customerRepository.findByContactFirstName(firstName) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findByContactFirstName(firstName);
	}

 

	@Override
	public Customers searchByContactLastName(String lastName) throws CustomerNotFoundException {
		if (customerRepository.findByContactLastName(lastName) == null) {
			throw new CustomerNotFoundException("the Customer with does not exists");
		}

 

		return customerRepository.findByContactLastName(lastName);
	}

 

	@Override
	public Customers updateCustomerName(int customerNumber, String newCustomerName) throws CustomerNotFoundException {
		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("the employee with does not exists");

 

		Customers customer = customerRepository.findById(customerNumber).get();

 

		customer.setCustomerName(newCustomerName);

 

		return customerRepository.save(customer);
	}

 

	@Override
	public Customers updateCustomerLastName(int customerNumber, String newCustomerLastName)
			throws CustomerNotFoundException {

 

		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("the employee with does not exists");

 

		Customers customer = customerRepository.findById(customerNumber).get();

 

		customer.setContactLastName(newCustomerLastName);

 

		return customerRepository.save(customer);

 

	}

 

	@Override
	public Customers updateContactFirstName(int customerNumber, String newContactFirstName)
			throws CustomerNotFoundException {
		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("the employee with does not exists");

 

		Customers customer = customerRepository.findById(customerNumber).get();

 

		customer.setContactFirstName(newContactFirstName);

 

		return customerRepository.save(customer);
	}

 

	@Override
	public Customers updateCustomerAddress(int customerNumber, String newCustomerAddress)
			throws CustomerNotFoundException {
		if (customerRepository.findById(customerNumber).isEmpty())

 

			throw new CustomerNotFoundException("the employee with does not exists");

 

		Customers customer = customerRepository.findById(customerNumber).get();

 

		customer.setAddressLine1(newCustomerAddress);

 

		return customerRepository.save(customer);
	}

 

	@Override
	public List<Customers> searchCustomersByCreditLimit(double creditLimt) throws CustomerNotFoundException {
		return customerRepository.findByCreditLimit(creditLimt);
	}

 

	@Override
	public List<Customers> searchCustomersByPostalCode(String postalCode) throws CustomerNotFoundException {
		return customerRepository.findByPostalCode(postalCode);
	}

 

	@Override
	public List<Customers> searchByHighCreditLimit(double creditLimit) {
		// TODO Auto-generated method stub
		return customerRepository.findByHighCreditLimit(creditLimit);
	}

 

	@Override
	public List<Customers> searchByLowCreditLimit(double creditLimit) {
		// TODO Auto-generated method stub
		return customerRepository.findByLowCreditLimit(creditLimit);
	}

	public List<Customers> getCustomersInCreditRange(double startCredit, double endCredit) {        

 

		return customerRepository.findCustomersInCreditRange(startCredit, endCredit);     }

 

	public List<OrderPaymentDetailsDto> getOrderPaymentDetailsForCustomer(String customerName) {
        return orderDetailsRepository.findOrderPaymentDetailsByCustomerName(customerName);
    }
	
	
	@Override
    public List<Payments> getPaymentDetailsByCustomerId(int customerNumber) {
        return paymentRepository.findPaymentsByCustomerNumber(customerNumber);
    }

 

 

	
}