package com.example.demo.services;

 

import java.util.List;

import com.example.demo.entities.Customers;
import com.example.demo.entities.Offices;
import com.example.demo.exception.OfficeNotFoundException;

 

public interface OfficeService {

	Offices createOffice(Offices office);

	List<Offices> getAllOffices();

	Offices updateOffices(Offices office) throws OfficeNotFoundException;

	Offices getOfficebyId(int code) throws OfficeNotFoundException;

	void deleteOffices(int code) throws OfficeNotFoundException;
	
	//update office phone number
	Offices updatePhone(int code, String phone) throws OfficeNotFoundException;
	
	//List<Offices> getOfficesByCities(List<String> cityNames) throws OfficeNotFoundException;
	
	Offices updateAddress(int code, String address) throws OfficeNotFoundException ;
	
	List<Offices> getOfficesByCities(List<String> cities);
	
	Offices createOfficeWithEmployees(Offices newOffice);
	
	public List<Customers> getAllCustomersOfofficeCode(int officeCode);

 

}