package com.example.demo.services;

 

import java.util.List;

import com.example.demo.dto.OrderDetailDTO;
import com.example.demo.entities.OrderDetails;

 

public interface OrderDetailsService {

 

	 OrderDetails addOrderDetails(OrderDetails orderDetails);
		/*
		 * OrderDetails updateQuantityOfOrderProduct(int orderNumber, String
		 * productCode, int quantityOrdered); List<OrderDetails> getByOrderNumber(int
		 * orderNumber); double getTotalAmountByOrderNumber(int orderNumber); int
		 * getByTotalSale(); double getOrderDetailsByMaxPriceOrder(); int
		 * getOrderDetailCountByOrderNumber(int orderNumber);
		 * 
		 * //extra for exceptions public OrderDetails getByOrderNumberAndProductCode(int
		 * orderNumber, String productCode);
		 */
	  List<OrderDetails> getByOrderNumber(int orderNumber);
	  // int getOrderDetailCountByOrderNumber(int orderNumber);
	double getOrderDetailsByMaxPriceOrder();
	int getOrderDetailCountByOrderNumber(int orderNumber);
	Double getTotalOrderAmount(int orderNumber);
	Double getTotalSale();
	String updateQuantityOrdered(int orderNumber, String productCode, int quantityOrdered);
	void addOrderDetails(OrderDetailDTO orderDetailsDTO) throws Exception;

 

	  

 

}