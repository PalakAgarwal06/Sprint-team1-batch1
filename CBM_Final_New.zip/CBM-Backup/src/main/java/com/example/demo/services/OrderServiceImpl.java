
  package com.example.demo.services;
  
  import java.util.Date;
import java.util.*;
import java.util.List;
  
  import org.springframework.beans.factory.annotation.Autowired; 
  import org.springframework.stereotype.Service;

import com.example.demo.dto.ProductLineDTO;
import com.example.demo.entities.Employees;
import com.example.demo.entities.Order;
import com.example.demo.entities.OrderDetails;
import com.example.demo.entities.Payments;
import com.example.demo.entities.Product;
import com.example.demo.entities.ProductLine;
import com.example.demo.exception.EmployeeNotFoundException;
import com.example.demo.exception.OrderDetailsNotFoundException;
import com.example.demo.exception.OrderNotFoundException;
  
  import com.example.demo.repository.OrdersRepository;
import com.example.demo.repository.ProductlinesRepository;
  
  @Service 
  public class OrderServiceImpl implements OrderService {
  
  @Autowired 
  OrdersRepository orepo;
  
   
  ProductlinesRepository productLineRepository;

  @Autowired
  public void ProductLineServiceImpl(ProductlinesRepository productLineRepository) {
      this.productLineRepository = productLineRepository;
  }
  
  @Override
  
  public Order createOrder(Order order) {
  
  return orepo.save(order);
  
  }
  
  @Override
  
  public List<Order> getAllOrder(Order order) {
  
  // TODO Auto-generated method stub
  
  return orepo.findAll();
  
  }
  
  @Override
  
  public Order updateOrder(Order order) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(order.getOrderNumber()).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  return orepo.save(order);
  
  }
  
  }
  
  @Override
  
  public Order getOrderById(int orderNumber) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(orderNumber).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  return orepo.findById(orderNumber).get();
  
  }
  
  }
  
  @Override
  
  public void deleteOrder(int orderNumber) throws OrderNotFoundException {
  
  // TODO Auto-generated method stub
  
  if (orepo.findById(orderNumber).isEmpty()) {
  
  throw new OrderNotFoundException("Order Not Found");
  
  }
  
  else {
  
  orepo.deleteById(orderNumber);
  
  }
  
  }

@Override
public Order updateOrderShippedDate(int orderNumber, Date shippedDate) throws OrderNotFoundException {
	
	if(orepo.findById(orderNumber).isEmpty())
		  
		  throw new OrderNotFoundException("the order with" + orderNumber +
		  "does not exists");
		  
		  Order orders=orepo.findById(orderNumber).get();
		  
		  orders.setShippedDate(shippedDate);
		  
		  return orepo.save(orders);
		  
		  }
@Override
public List<Order> getOrdersByOrderDate(Date requiredDate) {
    return orepo.findOrdersByOrderDate(requiredDate);
}

@Override
public List<Order> getOrdersByRequiredDate(Date requiredDate) {
    return orepo.findOrdersByRequiredDate(requiredDate);
}

@Override
public List<Order> getOrdersByShippedDate(Date shippedDate){
    return orepo.findOrdersByShippedDate(shippedDate);
}

@Override
public List<Order> getOrdersByStatus(String status) {
    return orepo.findOrdersByStatus(status);
}

@Override
public Order updateOrderStatus(int orderNumber, String status) throws OrderNotFoundException {
	if(orepo.findById(orderNumber).isEmpty())
		  
		  throw new OrderNotFoundException("the order with" + orderNumber +
		  "does not exists");
		  
		  Order orders=orepo.findById(orderNumber).get();
		  
		  orders.setStatus(status);
		  
		  return orepo.save(orders);
		  
		  }

public List<Order> getOrdersByCustomerNumberAndStatus(int customerNumber, String status) {
    return orepo.findOrdersByCustomerNumberAndStatus(customerNumber, status);
}

@Override
public List<String> getProductNamesByOrderId(int orderId) {
    return orepo.findProductNamesByOrderId(orderId);
    
}

@Override
public List<Product> findAllProducts() {
    return orepo.findAllProducts();
}
@Override
public List<Order> findDeliveredOrdersWithSameDate(String status) {
    return orepo.findDeliveredOrdersWithSameDate(status);
}

@Override
public List<ProductLineDTO> findProductAndProductLineDetailsByShipmentDate(java.sql.Date shipmentDate) {
	return orepo.findProductAndProductLineDetailsByShipmentDate(shipmentDate);
}

@Override
public List<Product> getProductByOrderNumber(int orderNumber) {
	// TODO Auto-generated method stub
	return orepo.findProductDetailByOrderNumber(orderNumber);
}

}





 